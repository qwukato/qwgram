pub(crate) const OP_DIALOG: i32 = 0;
pub(crate) const OP_PROMPT: i32 = 1;
pub(crate) const OP_CHOOSER: i32 = 2;
pub(crate) const OP_BULLETIN: i32 = 3;
pub(crate) const OP_PICK_FILE: i32 = 4;
pub(crate) const OP_SAVE_FILE: i32 = 5;
pub(crate) const OP_SELECT_PEERS: i32 = 6;

pub(crate) mod actions;
pub(crate) mod dialogs;
pub(crate) mod files;
pub(crate) mod history;
pub(crate) mod icons;
pub(crate) mod pages;
pub(crate) mod screens;
