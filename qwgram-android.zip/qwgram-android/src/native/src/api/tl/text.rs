use rquickjs::{Array, Ctx, Exception, Function, Object, Result as JsResult, Value};
use tgtext::{DateFormat, Entity, EntityKind, Sub, TextWithEntities};

const KIND_MARKDOWN: i32 = 0;
const KIND_HTML: i32 = 1;
const KIND_HTML_RAW: i32 = 2;

pub fn install_text<'js>(ctx: &Ctx<'js>) -> JsResult<Object<'js>> {
  let natives = Object::new(ctx.clone())?;

  natives.set(
    "parse",
    Function::new(
      ctx.clone(),
      |ctx: Ctx<'js>, kind: i32, parts: Value<'js>, subs: Value<'js>| -> JsResult<Object<'js>> {
        let parts = read_parts(&ctx, &parts)?;
        let subs = read_subs(&ctx, &subs)?;
        let borrowed: Vec<&str> = parts.iter().map(String::as_str).collect();
        let parsed = match kind {
          KIND_MARKDOWN => tgtext::markdown::parse(&borrowed, &subs),
          KIND_HTML => tgtext::html::parse(false, &borrowed, &subs),
          KIND_HTML_RAW => {
            let dedented = tgtext::html::dedent(&borrowed);
            let dedented: Vec<&str> = dedented.iter().map(String::as_str).collect();
            tgtext::html::parse(true, &dedented, &subs)
          }
          _ => return Err(Exception::throw_type(&ctx, "parse: unknown format")),
        };
        text_to_js(&ctx, &parsed)
      },
    )?,
  )?;

  natives.set(
    "unparse",
    Function::new(ctx.clone(), |ctx: Ctx<'js>, kind: i32, text: String, entities: Value<'js>| -> JsResult<String> {
      let entities = read_entities(&ctx, &entities)?;
      Ok(match kind {
        KIND_MARKDOWN => tgtext::markdown::unparse(&text, &entities),
        KIND_HTML => tgtext::html::unparse(false, &text, &entities),
        KIND_HTML_RAW => tgtext::html::unparse(true, &text, &entities),
        _ => return Err(Exception::throw_type(&ctx, "unparse: unknown format")),
      })
    })?,
  )?;

  natives.set(
    "escape",
    Function::new(ctx.clone(), |ctx: Ctx<'js>, kind: i32, text: String, quote: bool| -> JsResult<String> {
      Ok(match kind {
        KIND_MARKDOWN => tgtext::markdown::escape(&text),
        KIND_HTML | KIND_HTML_RAW => tgtext::html::escape(&text, quote),
        _ => return Err(Exception::throw_type(&ctx, "escape: unknown format")),
      })
    })?,
  )?;

  Ok(natives)
}

fn read_parts<'js>(ctx: &Ctx<'js>, value: &Value<'js>) -> JsResult<Vec<String>> {
  let Some(array) = value.as_array() else {
    return Err(Exception::throw_type(ctx, "parse: expected template parts"));
  };
  let mut parts = Vec::with_capacity(array.len());
  for item in array.iter::<Value>() {
    let item = item?;
    let Some(text) = item.as_string() else {
      return Err(Exception::throw_type(ctx, "parse: template parts must be strings"));
    };
    parts.push(text.to_string()?);
  }
  Ok(parts)
}

fn read_subs<'js>(ctx: &Ctx<'js>, value: &Value<'js>) -> JsResult<Vec<Sub>> {
  let Some(array) = value.as_array() else {
    return Err(Exception::throw_type(ctx, "parse: expected interpolated values"));
  };
  let mut subs = Vec::with_capacity(array.len());
  for item in array.iter::<Value>() {
    let item = item?;
    if item.is_null() || item.is_undefined() {
      subs.push(Sub::Skip);
      continue;
    }
    if let Some(text) = item.as_string() {
      subs.push(Sub::Text(text.to_string()?));
      continue;
    }
    let Some(object) = item.as_object() else {
      return Err(Exception::throw_type(ctx, "parse: expected a string or { text, entities }"));
    };
    let text: Value = object.get("text")?;
    let Some(text) = text.as_string() else {
      return Err(Exception::throw_type(ctx, "parse: expected a string or { text, entities }"));
    };
    let entities = read_entities(ctx, &object.get("entities")?)?;
    subs.push(Sub::Rich(TextWithEntities { text: text.to_string()?, entities }));
  }
  Ok(subs)
}

pub(crate) fn read_entities<'js>(ctx: &Ctx<'js>, value: &Value<'js>) -> JsResult<Vec<Entity>> {
  if value.is_undefined() || value.is_null() {
    return Ok(Vec::new());
  }
  let Some(array) = value.as_array() else {
    return Err(Exception::throw_type(ctx, "entities must be an array"));
  };
  let mut entities = Vec::with_capacity(array.len());
  for item in array.iter::<Value>() {
    entities.push(read_entity(ctx, &item?)?);
  }
  Ok(entities)
}

fn read_entity<'js>(ctx: &Ctx<'js>, value: &Value<'js>) -> JsResult<Entity> {
  let Some(object) = value.as_object() else {
    return Err(Exception::throw_type(ctx, "entities: expected message entity objects"));
  };
  let name: Value = object.get("_")?;
  let Some(name) = name.as_string() else {
    return Err(Exception::throw_type(ctx, "entities: an entity needs its constructor name"));
  };
  let name = name.to_string()?;
  let offset = get_number_field(ctx, object, "offset")?;
  let length = get_number_field(ctx, object, "length")?;
  Ok(Entity::new(read_entity_kind(&name, object)?, offset, length))
}

/// The app's own json of a `messageEntity` vector, as `TlJson` writes it. An entity that does not
/// read is left out: this is what the app already shows, not plugin input.
pub(crate) fn read_entities_json(json: &str) -> Vec<Entity> {
  let Ok(serde_json::Value::Array(items)) = serde_json::from_str(json) else {
    return Vec::new();
  };
  items
    .iter()
    .filter_map(|item| {
      let object = item.as_object()?;
      let name = object.get("_")?.as_str()?;
      let offset = object.get("offset")?.as_i64()?;
      let length = object.get("length")?.as_i64()?;
      let Ok(kind) = read_entity_kind(name, object);
      Some(Entity::new(kind, offset, length))
    })
    .collect()
}

/// An entity's fields, read off a plugin's js object or off the app's json
trait EntityFields: Sized {
  type Error;
  fn string(&self, name: &str) -> Result<Option<String>, Self::Error>;
  fn boolean(&self, name: &str) -> Result<bool, Self::Error>;
  /// an int64 the app writes as a number where it fits and as a decimal string otherwise
  fn int64(&self, name: &str) -> Result<Option<i64>, Self::Error>;
  /// same, kept as text: a document id is only ever passed along, and 2^53 is not its ceiling
  fn id_string(&self, name: &str) -> Result<Option<String>, Self::Error>;
  fn object(&self, name: &str) -> Option<Self>;
}

fn read_entity_kind<F: EntityFields>(name: &str, fields: &F) -> Result<EntityKind, F::Error> {
  Ok(match name {
    "messageEntityBold" => EntityKind::Bold,
    "messageEntityItalic" => EntityKind::Italic,
    "messageEntityUnderline" => EntityKind::Underline,
    "messageEntityStrike" => EntityKind::Strike,
    "messageEntitySpoiler" => EntityKind::Spoiler,
    "messageEntityCode" => EntityKind::Code,
    "messageEntityPre" => EntityKind::Pre {
      language: fields.string("language")?.unwrap_or_default(),
    },
    "messageEntityBlockquote" => EntityKind::Blockquote { collapsed: fields.boolean("collapsed")? },
    "messageEntityTextUrl" => EntityKind::TextUrl {
      url: fields.string("url")?.unwrap_or_default(),
    },
    "messageEntityMentionName" => EntityKind::MentionName {
      user_id: fields.int64("user_id")?.unwrap_or_default(),
    },
    "inputMessageEntityMentionName" => {
      let user = fields.object("user_id");
      let user_id = user.as_ref().and_then(|user| user.int64("user_id").ok().flatten()).unwrap_or_default();
      let access_hash = user.as_ref().and_then(|user| user.int64("access_hash").ok().flatten()).unwrap_or_default();
      EntityKind::InputMentionName { user_id, access_hash }
    }
    "messageEntityCustomEmoji" => EntityKind::CustomEmoji {
      document_id: fields.id_string("document_id")?.unwrap_or_else(|| "0".into()),
    },
    "messageEntityFormattedDate" => EntityKind::FormattedDate {
      date: fields.int64("date")?.unwrap_or_default(),
      format: DateFormat {
        relative: fields.boolean("relative")?,
        day_of_week: fields.boolean("day_of_week")?,
        short_date: fields.boolean("short_date")?,
        long_date: fields.boolean("long_date")?,
        short_time: fields.boolean("short_time")?,
        long_time: fields.boolean("long_time")?,
      },
    },
    "messageEntityUrl" => EntityKind::Url,
    "messageEntityEmail" => EntityKind::Email,
    "messageEntityMention" => EntityKind::Mention,
    _ => EntityKind::Other(name.to_string()),
  })
}

impl<'js> EntityFields for Object<'js> {
  type Error = rquickjs::Error;

  fn string(&self, name: &str) -> JsResult<Option<String>> {
    let value: Value = self.get(name)?;
    match value.as_string() {
      Some(value) => Ok(Some(value.to_string()?)),
      None => Ok(None),
    }
  }

  fn boolean(&self, name: &str) -> JsResult<bool> {
    let value: Value = self.get(name)?;
    Ok(value.as_bool().unwrap_or(false))
  }

  fn int64(&self, name: &str) -> JsResult<Option<i64>> {
    let value: Value = self.get(name)?;
    if let Some(value) = value.as_number() {
      if value.is_finite() && value.fract() == 0.0 {
        return Ok(Some(value as i64));
      }
    }
    if let Some(value) = value.as_string() {
      return Ok(value.to_string()?.parse::<i64>().ok());
    }
    Ok(None)
  }

  fn id_string(&self, name: &str) -> JsResult<Option<String>> {
    let value: Value = self.get(name)?;
    if let Some(value) = value.as_string() {
      let value = value.to_string()?;
      return Ok(if value.is_empty() { None } else { Some(value) });
    }
    if let Some(value) = value.as_number() {
      if value.is_finite() && value.fract() == 0.0 {
        return Ok(Some((value as i64).to_string()));
      }
    }
    Ok(None)
  }

  fn object(&self, name: &str) -> Option<Self> {
    self.get::<_, Value>(name).ok()?.into_object()
  }
}

impl EntityFields for serde_json::Map<String, serde_json::Value> {
  type Error = std::convert::Infallible;

  fn string(&self, name: &str) -> Result<Option<String>, Self::Error> {
    Ok(self.get(name).and_then(|value| value.as_str()).map(str::to_string))
  }

  fn boolean(&self, name: &str) -> Result<bool, Self::Error> {
    Ok(self.get(name).and_then(|value| value.as_bool()).unwrap_or(false))
  }

  fn int64(&self, name: &str) -> Result<Option<i64>, Self::Error> {
    Ok(match self.get(name) {
      Some(serde_json::Value::String(value)) => value.parse().ok(),
      Some(value) => value.as_i64(),
      None => None,
    })
  }

  fn id_string(&self, name: &str) -> Result<Option<String>, Self::Error> {
    Ok(match self.get(name) {
      Some(serde_json::Value::String(value)) if !value.is_empty() => Some(value.clone()),
      Some(value) => value.as_i64().map(|value| value.to_string()),
      None => None,
    })
  }

  fn object(&self, name: &str) -> Option<Self> {
    self.get(name)?.as_object().cloned()
  }
}

pub(crate) fn text_to_js<'js>(ctx: &Ctx<'js>, value: &TextWithEntities) -> JsResult<Object<'js>> {
  let out = Object::new(ctx.clone())?;
  out.set("text", value.text.as_str())?;
  let entities = Array::new(ctx.clone())?;
  for (index, entity) in value.entities.iter().enumerate() {
    entities.set(index, entity_to_js(ctx, entity)?)?;
  }
  out.set("entities", entities)?;
  Ok(out)
}

fn entity_to_js<'js>(ctx: &Ctx<'js>, entity: &Entity) -> JsResult<Object<'js>> {
  let out = Object::new(ctx.clone())?;
  out.set("_", entity.kind.name())?;
  // these cross as js numbers, not bigints: an offset is a count of code units and an id the app
  // itself writes as a number wherever it fits
  out.set("offset", entity.offset as f64)?;
  out.set("length", entity.length as f64)?;

  match &entity.kind {
    EntityKind::Pre { language } => out.set("language", language.as_str())?,
    EntityKind::Blockquote { collapsed } => out.set("collapsed", *collapsed)?,
    EntityKind::TextUrl { url } => out.set("url", url.as_str())?,
    EntityKind::MentionName { user_id } => out.set("user_id", *user_id as f64)?,
    EntityKind::InputMentionName { user_id, access_hash } => {
      let user = Object::new(ctx.clone())?;
      user.set("_", "inputUser")?;
      user.set("user_id", *user_id as f64)?;
      // an int64 the plugin never does arithmetic on, so it crosses as the app's decimal string
      user.set("access_hash", access_hash.to_string())?;
      out.set("user_id", user)?;
    }
    EntityKind::CustomEmoji { document_id } => out.set("document_id", document_id.as_str())?,
    EntityKind::FormattedDate { date, format } => {
      out.set("date", *date as f64)?;
      for (name, set) in [
        ("relative", format.relative),
        ("day_of_week", format.day_of_week),
        ("short_date", format.short_date),
        ("long_date", format.long_date),
        ("short_time", format.short_time),
        ("long_time", format.long_time),
      ] {
        if set {
          out.set(name, true)?;
        }
      }
    }
    _ => {}
  }

  Ok(out)
}

fn get_number_field<'js>(ctx: &Ctx<'js>, object: &Object<'js>, name: &str) -> JsResult<i64> {
  let value: Value = object.get(name)?;
  match value.as_number() {
    Some(value) if value.is_finite() && value.fract() == 0.0 => Ok(value as i64),
    _ => Err(Exception::throw_type(ctx, &format!("entities: {name} must be an integer"))),
  }
}
