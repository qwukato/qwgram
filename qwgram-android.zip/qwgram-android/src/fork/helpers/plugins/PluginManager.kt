package desu.inugram.helpers.plugins

import android.content.Context
import android.os.SystemClock
import desu.inugram.InuConfig
import desu.inugram.core.plugins.FsQuota
import desu.inugram.core.plugins.GrantCatalog
import desu.inugram.core.plugins.GrantValidator
import desu.inugram.core.plugins.PluginAsset
import desu.inugram.core.plugins.PluginAssetsException
import desu.inugram.core.plugins.PluginAssetsParser
import desu.inugram.core.plugins.PluginInstalls
import desu.inugram.core.plugins.PluginManifest
import desu.inugram.core.plugins.PluginManifestParser
import desu.inugram.core.plugins.PluginPermissions
import desu.inugram.core.plugins.PluginOrigin
import desu.inugram.core.plugins.TlTables
import desu.inugram.helpers.ShortcutHelper
import desu.inugram.helpers.plugins.io.PluginAssetFiles
import desu.inugram.helpers.plugins.io.PluginBlobs
import desu.inugram.helpers.plugins.io.PluginFetch
import desu.inugram.helpers.plugins.io.PluginFs
import desu.inugram.helpers.plugins.io.PluginLocalStorage
import desu.inugram.helpers.plugins.io.PluginSqlite
import desu.inugram.helpers.plugins.io.PluginPaths
import desu.inugram.helpers.plugins.io.PluginTransfers
import desu.inugram.helpers.plugins.platform.PluginJvm
import desu.inugram.helpers.plugins.platform.PluginNotifications
import desu.inugram.helpers.plugins.platform.PluginPlatform
import desu.inugram.helpers.plugins.platform.PluginXposed
import desu.inugram.helpers.plugins.telegram.PluginAccounts
import desu.inugram.helpers.plugins.telegram.PluginMedia
import desu.inugram.helpers.plugins.telegram.PluginOptimisticSend
import desu.inugram.helpers.plugins.telegram.PluginRpc
import desu.inugram.helpers.plugins.telegram.PluginSends
import desu.inugram.helpers.plugins.telegram.PluginMessageFilters
import desu.inugram.helpers.plugins.telegram.PluginTextEntities
import desu.inugram.helpers.plugins.telegram.PluginTranslation
import desu.inugram.helpers.plugins.telegram.PluginUpdates
import desu.inugram.helpers.plugins.tl.TlReflect
import desu.inugram.helpers.plugins.ui.PluginActions
import desu.inugram.helpers.plugins.ui.PluginAppVisibility
import desu.inugram.helpers.plugins.ui.PluginCanvas
import desu.inugram.helpers.plugins.ui.PluginFilePicker
import desu.inugram.helpers.plugins.ui.PluginChatHistory
import desu.inugram.helpers.plugins.ui.PluginUi
import desu.inugram.helpers.update.UpdateHelper
import desu.inugram.ui.settings.PluginTextSheet
import desu.inugram.ui.settings.findGrantsBeyond
import desu.inugram.ui.settings.sortedGrants
import org.telegram.messenger.AndroidUtilities
import org.telegram.messenger.ApplicationLoader
import org.telegram.messenger.BuildVars
import org.telegram.messenger.LocaleController
import org.telegram.messenger.NotificationCenter
import org.telegram.messenger.LocaleController.formatString
import org.telegram.messenger.LocaleController.getString
import org.telegram.messenger.R
import org.telegram.messenger.SharedConfig
import org.telegram.tgnet.TLRPC
import org.telegram.ui.Components.BulletinFactory
import org.telegram.ui.LaunchActivity
import java.io.File
import java.util.IdentityHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Engine ops run on [EngineDispatch.scheduler]; structural list/flag mutations on the ui thread. */
object PluginManager {
    const val SAFE_MODE_ACTION = "desu.inugram.action.SAFE_MODE"
    const val PLUGIN_API_VERSION = GrantCatalog.PLUGIN_API
    private const val PLATFORM = "android"

    private const val LOG_BUDGET = 200
    private const val LOG_WINDOW_MS = 10_000L

    @Suppress("DEPRECATION")
    private val appBuild by lazy { UpdateHelper.packageInfo?.versionCode?.toString() ?: "0" }

    private val plugins = mutableListOf<Plugin>()

    /** a minted id is random, so none will be this one; boot sweeps its storage as an orphan */
    private val SCRATCH_ID = "0".repeat(PluginInstalls.ID_LENGTH)

    /**
     * `inu eval --scratch`: every grant, created on demand and never stored or listed. Dispatch reaches
     * it through [getDispatchTargets]. Ui-thread owned
     */
    @Volatile private var scratch: Plugin? = null
    private var unannouncedCrash: Plugin? = null

    // the engine queue reads the order to sort interceptor chains while the ui thread mutates it
    @Volatile
    private var snapshot: List<Plugin> = emptyList()

    private val guard = BootGuard()

    val safeMode: Boolean get() = guard.safeMode

    val safeModeReason: BootGuard.Reason? get() = guard.reason

    private var booted = false
    private var lateLoaded = false
    private var loaded = false
    private var hosting = false

    /** read first by every stock hook, so a disabled engine costs one volatile read */
    @Volatile
    var anyRunning = false
        private set

    fun refreshAnyRunning() {
        anyRunning = snapshot.any { it.session != null } || scratch?.session != null
    }

    // the plugins page and an info page can be mounted at once, and the revealed fragment resumes before the other pauses
    private val changeListeners = CopyOnWriteArrayList<() -> Unit>()

    fun init(context: Context) {
        if (!isEngineEnabled()) return
        startHosting(context)
    }

    /** with the engine off, registers no observers and does not read the plugin directory */
    private fun startHosting(context: Context) {
        if (hosting) return
        hosting = true
        PluginAppVisibility.watch(context)
        PluginAccounts.watch()
        watchLanguage()
        PluginBlobs.scheduleSweep()
        PluginTransfers.scheduleSweep()
        ensureLoaded()
        PluginDevServer.sync(context)
    }

    /** the plugins page needs this with the engine disabled too */
    fun ensureLoaded() {
        if (loaded) return
        loaded = true
        val stored = PluginStore.load()
        plugins.addAll(stored.orEmpty())
        PluginStore.persist(plugins)
        republishOrder()
        if (stored != null) sweepOrphans(PluginStore.installIds(plugins))
    }

    /** runs before any plugin can start, so no engine is creating a store meanwhile */
    private fun sweepOrphans(live: Set<String>) {
        PluginFs.sweepOrphans(live)
        PluginAssetFiles.sweepOrphans(live)
        PluginLocalStorage.sweepOrphans(live)
        PluginSqlite.sweepOrphans(live)
        PluginJvm.sweepOrphans(live)
        PluginPaths.emptyTrash()
        PluginActions.retainInstalls(live)
        PluginTranslation.retainInstalls(live)
        PluginNotifications.sweepOrphans(live)
    }

    fun isEngineEnabled(): Boolean = InuConfig.PLUGINS_ENABLED.value

    fun plugins(): List<Plugin> = snapshot

    /** [plugins], and the scratch plugin last while it runs. For dispatch, never for anything shown */
    fun getDispatchTargets(): List<Plugin> {
        val scratch = scratch?.takeIf { it.session != null } ?: return snapshot
        return snapshot + scratch
    }

    /** `Plugin` has no `equals()` and a reload replaces the instance */
    fun orderIndex(): IdentityHashMap<Plugin, Int> {
        val order = IdentityHashMap<Plugin, Int>()
        snapshot.forEachIndexed { index, plugin -> order[plugin] = index }
        return order
    }

    /**
     * Runs at the end of `ApplicationLoader.postInitApplication`, which every entry point reaches, including
     * push wakeups that feed `processUpdates` without an activity. Blocks up to
     * [BootCohort.EARLY_BUDGET_MILLIS] so update processing waits for registrations.
     */
    fun onAppBoot() {
        if (booted || ApplicationLoader.applicationContext == null) return
        booted = true
        if (!isEngineEnabled()) return
        val loaded = CountDownLatch(1)
        EngineDispatch.scheduler.postRunnable {
            try {
                runPass { it.enabled && BootCohort.bootsEarly(PluginPermissions.parse(it.manifest.grants)) }
            } finally {
                loaded.countDown()
            }
        }
        loaded.await(BootCohort.EARLY_BUDGET_MILLIS, TimeUnit.MILLISECONDS)
    }

    fun onAppInteractive() {
        if (lateLoaded) return
        lateLoaded = true
        if (!isEngineEnabled()) return
        EngineDispatch.scheduler.postRunnable { runPass { it.enabled } }
    }

    private fun runPass(wanted: (Plugin) -> Boolean) {
        if (!guard.startPass()) {
            PluginLog.HOST.w("manager", "safe mode (${guard.reason}); skipping plugins")
            return
        }
        for (plugin in plugins()) {
            // arming is a durable write
            if (!wanted(plugin) || plugin.running) continue
            watchCrashes()
            guard.guardPlugin { start(plugin) }
        }
    }

    private var watchingCrashes = false

    /** plugin queue only */
    private fun watchCrashes() {
        if (watchingCrashes) return
        watchingCrashes = true
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            try {
                guard.recordCrash()
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, e)
        }
        EngineDispatch.scheduler.postRunnable({ guard.survivedWindow() }, BootGuard.CRASH_WINDOW_MILLIS)
    }

    /** plugin queue only; the looper resumes after this returns */
    fun onEngineThreadError(e: Throwable) {
        PluginLog.HOST.e("manager", "uncaught on the plugin thread, stopping every plugin", e)
        if (!guard.enterSafeMode(BootGuard.Reason.HOST_ERROR)) return
        for (plugin in plugins()) stop(plugin)
        scratch?.let { stop(it) }
        notifyChanged()
    }

    /** closes rather than restarts: android refuses a background activity start, and no alarm set here would fire in time */
    fun requestSafeMode() {
        guard.armForcedSafeMode()
        Runtime.getRuntime().exit(0)
    }

    fun toggleEngine(): Boolean {
        val enabled = InuConfig.PLUGINS_ENABLED.toggle()
        ApplicationLoader.applicationContext?.let { ShortcutHelper.sync(it) }
        if (enabled) ApplicationLoader.applicationContext?.let { startHosting(it) }
        if (enabled && !safeMode) {
            for (plugin in plugins) if (plugin.enabled) {
                plugin.failure = null
                run(plugin)
            }
        } else {
            for (plugin in plugins) stop(plugin)
            scratch?.let { stop(it) }
        }
        return enabled
    }

    fun setEnabled(plugin: Plugin, enabled: Boolean) {
        plugin.enabled = enabled
        if (enabled) plugin.failure = null
        PluginStore.persist(plugins)
        notifyChanged()
        if (enabled) {
            if (mayRun(plugin)) run(plugin)
        } else {
            stop(plugin)
        }
    }

    fun reload(plugin: Plugin) {
        stop(plugin)
        plugin.failure = null
        val source = try {
            plugin.file.readText()
        } catch (e: Exception) {
            fail(plugin, PluginFailure.Site.REFUSED, e.message ?: e.toString())
            return
        }
        val manifest = PluginManifestParser.parseOrNull(source)
        if (manifest == null) {
            fail(plugin, PluginFailure.Site.REFUSED, getString(R.string.InuPluginsErrorNoManifest))
            return
        }
        (badGrants(manifest) ?: badAssets(source))?.let {
            fail(plugin, PluginFailure.Site.REFUSED, it)
            return
        }
        plugin.source = source
        plugin.manifest = manifest
        notifyChanged()
        if (mayRun(plugin)) run(plugin)
    }

    fun findUpdateTarget(manifest: PluginManifest): Plugin? {
        val pluginId = manifest.id ?: return null
        // answered off the ui thread that mutates the list
        return plugins().firstOrNull { it.manifest.id == pluginId }
    }

    /**
     * Reuses the install id of a same-id record that failed to load this boot, to keep its otherwise
     * unreachable storage. Plugins already in the installed list go through [update].
     */
    fun import(source: String, enabled: Boolean = true, dev: Boolean = false, origin: PluginOrigin? = null): ImportResult {
        val manifest = PluginManifestParser.parseOrNull(source)
            ?: return ImportResult.Refused(getString(R.string.InuPluginsErrorNoManifest))
        (badGrants(manifest) ?: badAssets(source))?.let { return ImportResult.Refused(it) }
        val reclaimed = manifest.id?.let { PluginStore.findUnloaded(it) }
        val id = reclaimed?.id ?: PluginInstalls.mintId()
        val target = File(PluginStore.dir, PluginInstalls.fileName(id))
        if (!PluginStore.writeSource(target, source)) {
            return ImportResult.Refused(getString(R.string.InuPluginsErrorWrite))
        }
        reclaimed?.let { PluginStore.dropUnloaded(it) }
        val plugin = Plugin(id, target, source, manifest)
            .apply {
                this.enabled = enabled
                this.dev = dev
                this.grants = manifest.grants
                this.origin = origin
            }
        val reversible = reclaimed == null
        plugins.add(plugin)
        PluginStore.persist(plugins)
        republishOrder()
        notifyChanged()
        if (mayRun(plugin)) run(plugin)
        return ImportResult.Installed(plugin, reversible)
    }

    fun update(plugin: Plugin, source: String, dev: Boolean = false, origin: PluginOrigin? = null): String? {
        val manifest = PluginManifestParser.parseOrNull(source)
            ?: return getString(R.string.InuPluginsErrorNoManifest)
        (incompatibility(manifest) ?: badAssets(source))?.let { return it }
        if (!PluginStore.writeSource(plugin.file, source)) return getString(R.string.InuPluginsErrorWrite)
        plugin.dev = dev
        plugin.grants = manifest.grants
        plugin.origin = origin
        if (dev && !plugin.enabled && plugin.failure?.disables == true) plugin.enabled = true
        reload(plugin)
        PluginStore.persist(plugins)
        return null
    }

    /** main thread. [onReady] runs on the plugin queue with the running scratch session, or null when it did not start */
    fun withScratch(onReady: (PluginSession?) -> Unit) {
        val plugin = scratch ?: createScratch().also { scratch = it }
        plugin.enabled = true
        plugin.failure = null
        run(plugin) { onReady(plugin.session) }
    }

    /** stops the scratch plugin and wipes its storage; [after] runs on the plugin queue */
    fun resetScratch(after: () -> Unit = {}) {
        val plugin = scratch ?: return after()
        stop(plugin) {
            wipeInstall(plugin.id)
            after()
        }
    }

    private fun createScratch(): Plugin {
        val name = "Scratch"
        val grants = GrantCatalog.names.sorted()
        val manifest = PluginManifest(
            name = name,
            author = null,
            declaredId = null,
            version = null,
            description = null,
            localizedDescriptions = emptyMap(),
            icon = null,
            grants = grants,
            pluginApi = PLUGIN_API_VERSION,
            platform = PLATFORM,
            raw = mapOf("name" to listOf(name), "grant" to grants),
        )
        return Plugin(SCRATCH_ID, File(PluginStore.dir, PluginInstalls.fileName(SCRATCH_ID)), "", manifest).apply {
            dev = true
            this.grants = grants
        }
    }

    sealed interface ImportResult {
        /** false when this took over a failed record's id: [remove] would wipe storage that belonged to it */
        class Installed(val plugin: Plugin, val reversible: Boolean) : ImportResult
        class Refused(val reason: String) : ImportResult
    }

    fun remove(plugin: Plugin) {
        plugin.enabled = false
        plugin.failure = null
        // same queue as stop()'s completion, so the wipe is ordered after the engine is gone
        stop(plugin) { wipeInstall(plugin.id) }
        plugin.file.delete()
        plugins.remove(plugin)
        PluginStore.persist(plugins)
        PluginActions.retainInstalls(PluginStore.installIds(plugins))
        PluginTranslation.retainInstalls(PluginStore.installIds(plugins))
        republishOrder()
        notifyChanged()
    }

    fun setOrder(ordered: List<Plugin>) {
        if (ordered.size != plugins.size || !plugins.containsAll(ordered)) return
        plugins.clear()
        plugins.addAll(ordered)
        PluginStore.persist(plugins)
        republishOrder()
    }

    /** chain order is plugin-list order per `common.d.ts` */
    private fun republishOrder() {
        snapshot = plugins.toList()
        PluginRpc.refreshChainOrder()
        PluginSends.refreshOrder()
        PluginUpdates.refreshOrder()
        PluginMessageFilters.refreshOrder()
        PluginTextEntities.refreshOrder()
    }

    /** also the install flow's gate. `@plugin-api` reads like minSdkVersion: a shipped level never breaks */
    fun incompatibility(manifest: PluginManifest): String? {
        val wanted = manifest.pluginApi
        if (wanted != null && wanted > PLUGIN_API_VERSION) {
            return formatString(R.string.InuPluginsErrorApiVersion, wanted, PLUGIN_API_VERSION)
        }
        val platform = manifest.platform
        if (platform != null && !platform.equals(PLATFORM, ignoreCase = true)) {
            return formatString(R.string.InuPluginsErrorPlatform, platform)
        }
        return badGrants(manifest)
    }

    /**
     * The source is the plugin's to rewrite (`unsafe.fs` reaches the store), so grants run from what
     * the user consented to, never from the file alone.
     */
    private fun unconsentedGrants(plugin: Plugin): String? {
        val consented = plugin.grants
        val beyond = if (consented == null) sortedGrants(plugin.manifest.grants) else findGrantsBeyond(consented, plugin.manifest.grants)
        if (beyond.isEmpty()) return null
        val listed = beyond.joinToString(", ") { (name, scopes) -> if (scopes == null) name else "$name(${scopes.joinToString(",")})" }
        return formatString(R.string.InuPluginsErrorUnconsentedGrants, listed)
    }

    /** an unknown scope is a typo that narrowing would hide. unknown grant names stay ignored */
    private fun badGrants(manifest: PluginManifest): String? {
        val problems = GrantValidator.validateGrants(manifest.grants)
        if (problems.isEmpty()) return null
        return formatString(R.string.InuPluginsErrorBadGrant, problems.joinToString("; "))
    }

    fun badAssets(source: String): String? = try {
        PluginAssetsParser.parse(source)
        null
    } catch (e: PluginAssetsException) {
        formatString(R.string.InuPluginsErrorBadAssets, e.message)
    }

    private val stopping = java.util.IdentityHashMap<Plugin, MutableList<() -> Unit>>()

    private fun run(plugin: Plugin, after: () -> Unit = {}) {
        EngineDispatch.scheduler.postRunnable {
            val pending = stopping[plugin]
            if (pending != null) pending.add { start(plugin); after() }
            else { start(plugin); after() }
        }
    }

    private var warmed = false

    /** plugin queue only */
    private fun warmTlTables() {
        if (warmed) return
        warmed = true
        EngineDispatch.scheduler.postRunnable {
            TlTables.allNames
            TlReflect.prewarm()
        }
    }

    /** plugin queue only */
    private fun start(plugin: Plugin) {
        if (plugin.engine != null) return
        if (!mayRun(plugin)) return
        warmTlTables()
        incompatibility(plugin.manifest)?.let {
            fail(plugin, PluginFailure.Site.REFUSED, it)
            return
        }
        unconsentedGrants(plugin)?.let {
            fail(plugin, PluginFailure.Site.REFUSED, it)
            return
        }
        val session = PluginSession(plugin, QuickJs())
        plugin.session = session
        refreshAnyRunning()
        val budget = LogBudget()
        val timers = TimerThrottle(session)::schedule
        val onHost = EngineDispatch.createHostDispatcher(session::isCurrent)
        val core = object : CoreListener {
            private val faultReported = AtomicBoolean()

            override fun onConsole(level: Int, message: String) {
                logConsole(session, budget, level, message)
                if (level == QuickJs.LEVEL_FAULT && faultReported.compareAndSet(false, true)) {
                    EngineDispatch.onEngine(session) { fail(session, PluginFailure.Site.RUNTIME, message) }
                }
            }

            override fun onTimerSchedule(delayMs: Long) = onHost { timers(delayMs) }
        }
        // rust caches its method ids off `PluginBridge` at `start`
        val jvm = PluginJvm.listenerFor(session)
        val tl = session.tl
        val bridge = PluginBridge(
            core = core,
            rpc = PluginRpc.listenerFor(session),
            sends = PluginSends.listenerFor(session),
            updates = PluginUpdates.listenerFor(session),
            tl = tl,
            account = PluginAccounts.listenerFor(session),
            ui = PluginUi.listenerFor(session),
            platform = PluginPlatform.listenerFor(session.log),
            fetch = PluginFetch.listenerFor(session),
            canvas = PluginCanvas.listenerFor(session),
            notifications = PluginNotifications.listenerFor(session),
            translation = PluginTranslation.listenerFor(session),
            filters = PluginMessageFilters.listenerFor(session),
            textEntities = PluginTextEntities.listenerFor(session),
            jvm = jvm,
            xposed = PluginXposed.listenerFor(session, jvm),
        )
        try {
            val assets = PluginAssetFiles.extract(plugin.id, session.source, PluginAssetsParser.parse(session.source))
            // runs the JNI bridge wiring, which throws when a descriptor does not resolve
            startEngine(session, bridge, assets)
            installInfo(session)
            val code = session.source.substring(0, PluginAssetsParser.findFooter(session.source))
            session.engine.evaluate(code, session.manifest.name)
            notifyChanged()
        } catch (e: Throwable) {
            teardown(session) {
                // before the field is cleared: [fail] reads it to decide the fault is still this plugin's
                fail(session, PluginFailure.Site.LOAD, e.message ?: e.toString())
            }
        }
    }

    private fun installInfo(session: PluginSession) {
        session.engine.installInfo(
            appVersion = BuildVars.BUILD_VERSION_STRING,
            appBuild = appBuild,
            apiVersion = PLUGIN_API_VERSION,
            layer = TLRPC.LAYER,
            language = getLanguage(),
            header = session.manifest.raw,
        )
    }

    private fun getLanguage(): String = LocaleController.getInstance().currentLocaleInfo?.langCode ?: ""

    private var lastLanguage: String? = null

    /** `LocaleController` has no language-changed event, but posts `reloadInterface` after applying one */
    private fun watchLanguage() {
        AndroidUtilities.runOnUIThread {
            lastLanguage = getLanguage()
            NotificationCenter.getGlobalInstance().addObserver({ _, _, _ ->
                val language = getLanguage()
                if (language != lastLanguage) {
                    lastLanguage = language
                    EngineDispatch.scheduler.postRunnable {
                        for (plugin in getDispatchTargets()) plugin.session?.let(::installInfo)
                    }
                }
            }, NotificationCenter.reloadInterface)
        }
    }

    private fun startEngine(session: PluginSession, bridge: PluginBridge, assets: List<Pair<PluginAsset, String>>) {
        val quota = FsQuota.forGrants(session.manifest.grants)
        val sqliteQuota = FsQuota.forGrants(session.manifest.grants, "sqlite")
        session.engine.start(
            bridge,
            QuickJs.Config(
                spillDir = PluginBlobs.dirFor(session.plugin.id),
                transferDir = PluginTransfers.dirFor(session.plugin.id),
                fsDir = quota?.let { PluginFs.dirFor(session.plugin.id) } ?: "",
                fsQuotaBytes = quota ?: 0,
                fsUnscoped = session.permissions.has("unsafe.fs"),
                installFs = quota != null,
                androidDirs = PluginFs.androidDirs(),
                localStoragePath = PluginLocalStorage.pathFor(session.plugin.id),
                sqlitePath = sqliteQuota?.let { PluginSqlite.pathFor(session.plugin.id) } ?: "",
                sqliteQuotaBytes = sqliteQuota ?: 0,
                installJvm = bridge.jvm != null,
                installXposed = bridge.xposed != null,
                grants = session.permissions,
                assets = assets,
            ),
        )
        // no callback can hear this, the plugin's code not having run yet
        if (!PluginAppVisibility.isForeground) session.engine.appVisibilityChanged(PluginAppVisibility.MODE_BACKGROUND)
    }

    private fun mayRun(plugin: Plugin): Boolean = plugin.enabled && isEngineEnabled() && !safeMode

    private fun failUnload(session: PluginSession, e: Throwable) =
        fail(session, PluginFailure.Site.UNLOAD, e.message ?: e.toString())

    private fun wipeInstall(installId: String) {
        PluginLocalStorage.wipe(installId)
        PluginSqlite.wipe(installId)
        wipeSessionScratch(installId)
        PluginFs.wipe(installId)
        PluginAssetFiles.wipe(installId)
        PluginNotifications.wipe(installId)
        // a class cannot be unloaded, so staged dex outlives the engine
        PluginJvm.wipe(installId)
    }

    /** durable trees ([PluginFs], [PluginJvm], [PluginLocalStorage], [PluginSqlite]) are uninstall's alone */
    private fun wipeSessionScratch(installId: String) {
        PluginBlobs.wipe(installId)
        PluginTransfers.wipe(installId)
        PluginFetch.wipe(installId)
        PluginCanvas.wipe(installId)
    }

    private val CHAIN_OWNERS: List<SessionResource> = listOf(PluginRpc, PluginSends, PluginUpdates)

    private val SESSION_RESOURCES: List<SessionResource> = listOf(
        PluginMedia,
        PluginOptimisticSend,
        PluginUi,
        PluginChatHistory,
        PluginFilePicker,
        PluginFetch,
        PluginActions,
        PluginTranslation,
        PluginMessageFilters,
        PluginTextEntities,
        PluginNotifications,
        PluginCanvas,
        PluginXposed,
        PluginJvm,
    )

    /**
     * Xposed needs the JVM handle table while removing hooks. File cleanup waits for `close()`, which
     * releases rust's spill-file descriptors. [beforeClear] runs while `plugin.engine` is still [engine].
     */
    private fun teardown(session: PluginSession, beforeClear: () -> Unit = {}) {
        session.engine.stopCallbacks()
        // handle table released last: abandoned continuations may still read their own request view
        session.stopDispatching()
        for (owner in CHAIN_OWNERS) owner.detach(session)
        session.tl.releaseAll()
        for (resource in SESSION_RESOURCES) resource.detach(session)
        session.engine.close()
        wipeSessionScratch(session.plugin.id)
        beforeClear()
        session.plugin.session = null
        session.settingsPageId = null
        refreshAnyRunning()
        notifyChanged()
    }

    private fun stop(plugin: Plugin, after: () -> Unit = {}) {
        EngineDispatch.scheduler.postRunnable {
            stopping[plugin]?.let { it.add(after); return@postRunnable }
            val session = plugin.session
            if (session == null) { after(); return@postRunnable }
            stopping[plugin] = arrayListOf(after)
            fun finish() {
                try { teardown(session) }
                finally { stopping.remove(plugin)?.forEach { it() } }
            }
            try {
                session.stopDispatching()
                session.engine.stopCallbacks()
                session.engine.notifyUnload()
            } catch (e: Throwable) {
                failUnload(session, e)
                finish()
                return@postRunnable
            }
            val poll = object : Runnable {
                override fun run() {
                    try {
                        if (!session.engine.pollUnload()) {
                            EngineDispatch.scheduler.postRunnable(this, 16)
                            return
                        }
                    } catch (e: Throwable) {
                        failUnload(session, e)
                    }
                    finish()
                }
            }
            poll.run()
        }
    }

    /**
     * Faults arrive during JNI upcalls while the engine's `RefCell` is borrowed, so handling is posted.
     * Engine identity is checked on the queue that owns [Plugin.engine]: an `onUnload` failure during
     * reload must not disable the replacement engine.
     */
    private fun fail(session: PluginSession, at: PluginFailure.Site, detail: String) {
        if (session.isCurrent()) fail(session.plugin, at, detail)
    }

    private fun fail(plugin: Plugin, at: PluginFailure.Site, detail: String) {
        PluginLog.of(plugin).e("manager", "$at: $detail")
        val failure = PluginFailure(at, detail)
        AndroidUtilities.runOnUIThread {
            plugin.failure = failure
            if (failure.disables && plugin.enabled) {
                plugin.enabled = false
                PluginStore.persist(plugins)
                stop(plugin)
                unannouncedCrash = plugin
                announcePendingCrash()
            }
            notifyChanged()
        }
    }

    /** ui thread. Without a resumed, unlocked ui the crash waits for the next resume */
    fun announcePendingCrash() {
        if (!LaunchActivity.isResumed || SharedConfig.isWaitingForPasscodeEnter) return
        val plugin = unannouncedCrash ?: return
        unannouncedCrash = null
        val failure = plugin.failure?.takeIf { it.disables } ?: return
        BulletinFactory.global().createSimpleBulletin(
            R.raw.error,
            formatString(R.string.InuPluginCrashed, plugin.manifest.name),
            failure.describe(),
            getString(R.string.ViewAction),
        ) {
            LaunchActivity.instance?.let { PluginTextSheet.createForFailure(it, plugin.manifest.name, failure).show() }
        }.show()
    }

    private fun logConsole(session: PluginSession, budget: LogBudget, level: Int, message: String) {
        when (budget.charge(SystemClock.uptimeMillis())) {
            LogBudget.Verdict.DROP -> return
            LogBudget.Verdict.LAST -> {
                session.log.w("console", "spent its log budget ($LOG_BUDGET per ${LOG_WINDOW_MS / 1000}s); muting the rest")
                return
            }

            LogBudget.Verdict.PASS -> Unit
        }
        session.log.console(level, message)
    }

    private class LogBudget {
        private var windowStart = 0L
        private var used = 0

        @Synchronized
        fun charge(now: Long): Verdict {
            if (now - windowStart >= LOG_WINDOW_MS) {
                windowStart = now
                used = 0
            }
            if (used < LOG_BUDGET + 1) used++
            return when {
                used < LOG_BUDGET -> Verdict.PASS
                used == LOG_BUDGET -> Verdict.LAST
                else -> Verdict.DROP
            }
        }

        enum class Verdict { PASS, LAST, DROP }
    }

    fun addOnChangedListener(listener: () -> Unit) {
        changeListeners.addIfAbsent(listener)
    }

    fun removeOnChangedListener(listener: () -> Unit) {
        changeListeners.remove(listener)
    }

    /** anything mutating a [Plugin] field owes a call */
    fun notifyChanged() {
        AndroidUtilities.runOnUIThread { for (listener in changeListeners) listener() }
    }
}
