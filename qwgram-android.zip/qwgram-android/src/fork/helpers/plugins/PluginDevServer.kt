package desu.inugram.helpers.plugins

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import desu.inugram.InuConfig
import desu.inugram.core.plugins.PluginManifestParser
import desu.inugram.helpers.plugins.ui.PluginAppVisibility
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import org.json.JSONArray
import org.json.JSONObject
import org.telegram.messenger.AndroidUtilities
import org.telegram.messenger.LocaleController
import org.telegram.messenger.R
import org.telegram.ui.Components.BulletinFactory

/**
 * Skips review, with no undo. The receiver exists only after the user enables
 * [InuConfig.PLUGINS_DEV_MODE] and requires the sender's `android.permission.DUMP`, which `adb shell`
 * holds and ordinary apps cannot. Source is read only from the drop directory, never from extras.
 */
object PluginDevServer {
    const val ACTION = "desu.inugram.plugins.DEV"
    const val DIR = "plugin-dev"

    private const val SENDER_PERMISSION = "android.permission.DUMP"

    private val safeName = Regex("[A-Za-z0-9._-]+")

    private const val EVAL_DEFAULT_SECONDS = 10L

    /** an `am broadcast` is a background broadcast, which the system declares an ANR after 60s */
    private const val EVAL_MAX_SECONDS = 50L

    /** the reply crosses binder inside the broadcast result */
    private const val EVAL_MAX_CHARS = 64 * 1024

    private var registered = false

    /** idempotent */
    fun sync(context: Context) {
        val app = context.applicationContext
        if (InuConfig.PLUGINS_DEV_MODE.value) register(app) else unregister(app)
    }

    fun dropDir(context: Context): File? = context.applicationContext.getExternalFilesDir(DIR)

    private fun register(context: Context) {
        if (registered) return
        try {
            val filter = IntentFilter(ACTION)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                context.registerReceiver(receiver, filter, SENDER_PERMISSION, null, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(receiver, filter, SENDER_PERMISSION, null)
            }
            registered = true
            PluginLog.HOST.d("dev", "listening on $ACTION, drop dir ${dropDir(context)}")
        } catch (e: Exception) {
            PluginLog.HOST.e("dev", "could not register", e)
        }
    }

    private fun unregister(context: Context) {
        if (!registered) return
        registered = false
        PluginManager.resetScratch()
        try {
            context.unregisterReceiver(receiver)
        } catch (e: Exception) {
            PluginLog.HOST.e("dev", "could not unregister", e)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION) return
            when (intent.getStringExtra("cmd")) {
                "eval" -> return answerLater(isOrderedBroadcast, goAsync()) { startEval(context, intent, it) }
                "memory" -> return answerLater(isOrderedBroadcast, goAsync()) { startMemory(context, intent, it) }
            }
            // on the main thread, unlike other install paths: an ordered broadcast's result must be set before onReceive returns
            val reply = try {
                handle(context, intent)
            } catch (e: Exception) {
                PluginLog.HOST.e("dev", "command failed", e)
                fail(e.message ?: e.toString())
            }
            if (isOrderedBroadcast) resultData = reply.toString() else PluginLog.HOST.d("dev", reply.toString())
        }
    }

    private fun handle(context: Context, intent: Intent): JSONObject {
        return when (val cmd = intent.getStringExtra("cmd") ?: "ping") {
            "ping" -> JSONObject()
                .put("ok", true)
                .put("pluginApi", PluginManager.PLUGIN_API_VERSION)
                .put("engineEnabled", PluginManager.isEngineEnabled())
                .put("safeMode", PluginManager.safeMode)
                .put("dropDir", dropDir(context)?.absolutePath ?: "")

            "list" -> JSONObject().put("ok", true).put("plugins", listPlugins())
            "install" -> install(context, intent.getStringExtra("file"))
            "remove" -> remove(context, intent.getStringExtra("file"))
            else -> fail("unknown command: $cmd")
        }
    }

    private fun listPlugins(): JSONArray {
        val arr = JSONArray()
        for (plugin in PluginManager.plugins()) {
            arr.put(describe(plugin))
        }
        return arr
    }

    private fun describe(plugin: Plugin): JSONObject = JSONObject()
        .put("id", plugin.id)
        .put("name", plugin.manifest.name)
        .putOpt("pluginId", plugin.manifest.id)
        .put("file", plugin.file.name)
        .put("enabled", plugin.enabled)
        .put("running", plugin.running)
        .put("dev", plugin.dev)
        .putOpt("failure", plugin.failure?.describe())

    /** [name] null installs every source in the drop dir, in name order */
    private fun install(context: Context, name: String?): JSONObject {
        val results = resolve(context, name).map { installOne(it) }
        if (results.isEmpty()) return fail("nothing to install in ${dropDir(context)}")
        announce(results.filter { it.optBoolean("ok") })
        val arr = JSONArray()
        for (result in results) arr.put(result)
        return JSONObject().put("ok", results.all { it.optBoolean("ok") }).put("results", arr)
    }

    /** dev installs have no review or undo bulletin. Skipped in the background, or it would show on an unrelated screen later */
    private fun announce(installed: List<JSONObject>) {
        if (installed.isEmpty() || !PluginAppVisibility.isForeground) return
        val text = if (installed.size == 1) {
            val one = installed[0]
            val name = one.optJSONObject("plugin")?.optString("name").orEmpty()
            val res = if (one.optString("action") == "installed") R.string.InuPluginInstalled else R.string.InuPluginUpdated
            LocaleController.formatString(res, name)
        } else {
            LocaleController.formatPluralString("InuPluginsDevPushed", installed.size)
        }
        BulletinFactory.global().createSimpleBulletin(R.raw.info, text).show()
    }

    private fun installOne(file: File): JSONObject {
        val source = try {
            file.readText()
        } catch (e: Exception) {
            return failFile(file, "${e.message ?: e}")
        }
        val manifest = PluginManifestParser.parseOrNull(source)
            ?: return failFile(file, "no valid manifest header")
        PluginManager.incompatibility(manifest)?.let { return failFile(file, it) }

        val target = PluginManager.findUpdateTarget(manifest)
        if (target != null) {
            PluginManager.update(target, source, dev = true)?.let { return failFile(file, it) }
            return installed("updated", file, target)
        }
        return when (val result = PluginManager.import(source, enabled = true, dev = true)) {
            is PluginManager.ImportResult.Refused -> failFile(file, result.reason)
            is PluginManager.ImportResult.Installed -> installed("installed", file, result.plugin)
        }
    }

    private fun failFile(file: File, reason: String): JSONObject = fail("${file.name}: $reason")

    private fun installed(action: String, file: File, plugin: Plugin): JSONObject = JSONObject()
        .put("ok", true)
        .put("action", action)
        .put("file", file.name)
        .put("plugin", describe(plugin))

    /** resolved through the file's plugin id, as an install would land */
    private fun findInstalled(context: Context, name: String): Plugin? =
        resolve(context, name).firstOrNull()
            ?.let { runCatching { it.readText() }.getOrNull() }
            ?.let { PluginManifestParser.parseOrNull(it) }
            ?.let { PluginManager.findUpdateTarget(it) }

    private fun remove(context: Context, name: String?): JSONObject {
        if (name == null) return fail("remove needs --es file <name>")
        val target = findInstalled(context, name) ?: return fail("not installed: $name")
        val described = describe(target)
        PluginManager.remove(target)
        return JSONObject().put("ok", true).put("action", "removed").put("plugin", described)
    }

    /**
     * answers off the main thread so the result can be awaited: `am broadcast` blocks until
     * [BroadcastReceiver.PendingResult.finish]. [start] answers null once the engine owns the answer
     */
    private fun answerLater(ordered: Boolean, pending: BroadcastReceiver.PendingResult, start: ((JSONObject) -> Unit) -> JSONObject?) {
        val answered = AtomicBoolean()
        val answer = { reply: JSONObject ->
            if (answered.compareAndSet(false, true)) {
                if (ordered) pending.resultData = reply.toString() else PluginLog.HOST.d("dev", reply.toString())
                pending.finish()
            }
        }
        val refused = try {
            start(answer)
        } catch (e: Exception) {
            PluginLog.HOST.e("dev", "command failed", e)
            fail(e.message ?: e.toString())
        }
        refused?.let(answer)
    }

    /** every running plugin, or the one [Intent] `file` was pushed as */
    private fun startMemory(context: Context, intent: Intent, answer: (JSONObject) -> Unit): JSONObject? {
        val name = intent.getStringExtra("file")
        val plugins = if (name == null) PluginManager.plugins() else listOf(findInstalled(context, name) ?: return fail("not installed: $name"))
        val sessions = plugins.mapNotNull { it.session }
        if (name != null && sessions.isEmpty()) return fail("${plugins[0].manifest.name} is not running")
        AndroidUtilities.runOnUIThread({ answer(fail("no result after ${EVAL_DEFAULT_SECONDS}s")) }, EVAL_DEFAULT_SECONDS * 1000)
        EngineDispatch.scheduler.postRunnable {
            val arr = JSONArray()
            for (session in sessions) {
                if (!session.isCurrent()) continue
                val usage = session.engine.memoryUsage() ?: continue
                arr.put(JSONObject().put("plugin", describe(session.plugin)).put("usage", JSONObject(usage)))
            }
            answer(JSONObject().put("ok", true).put("plugins", arr))
        }
        return null
    }

    /**
     * null once the engine owns the answer. Without a plugin file it runs in the scratch plugin. Only dev
     * plugins otherwise: the code reads the plugin's storage, which adb otherwise cannot
     */
    private fun startEval(context: Context, intent: Intent, answer: (JSONObject) -> Unit): JSONObject? {
        val codeName = intent.getStringExtra("code") ?: return fail("eval needs --es code <name>")
        val codeFile = resolve(context, codeName).firstOrNull() ?: return fail("no code file $codeName in ${dropDir(context)}")
        val code = try {
            codeFile.readText()
        } finally {
            codeFile.delete()
        }
        val seconds = (intent.getStringExtra("timeout")?.toLongOrNull() ?: EVAL_DEFAULT_SECONDS).coerceIn(1L, EVAL_MAX_SECONDS)

        val name = intent.getStringExtra("file")
        if (name == null) {
            if (!PluginManager.isEngineEnabled()) return fail("plugins are disabled in settings")
            if (PluginManager.safeMode) return fail("plugins are in safe mode")
            AndroidUtilities.runOnUIThread({ answer(fail("no result after ${seconds}s")) }, seconds * 1000)
            val run = {
                PluginManager.withScratch { session ->
                    if (session == null) answer(fail("the scratch plugin did not start, see the app log"))
                    else evaluateIn(session, code, answer)
                }
            }
            if (intent.getStringExtra("reset") == "true") PluginManager.resetScratch { AndroidUtilities.runOnUIThread(run) } else run()
            return null
        }

        val target = findInstalled(context, name) ?: return fail("not installed: $name")
        if (!target.dev) return fail("${target.manifest.name} was not pushed from the cli, so eval is not allowed")
        val session = target.session ?: return fail("${target.manifest.name} is not running")
        AndroidUtilities.runOnUIThread({ answer(fail("no result after ${seconds}s")) }, seconds * 1000)
        evaluateIn(session, code, answer)
        return null
    }

    private fun evaluateIn(session: PluginSession, code: String, answer: (JSONObject) -> Unit) {
        val plugin = session.plugin
        EngineDispatch.onEngine(session, onDropped = { answer(fail("${plugin.manifest.name} reloaded before the code ran")) }) {
            session.engine.evaluateInspected(code) { fulfilled, text ->
                val shown = if (text.length <= EVAL_MAX_CHARS) text else "${text.take(EVAL_MAX_CHARS)}\n... ${text.length - EVAL_MAX_CHARS} more characters"
                answer(JSONObject().put("ok", true).put("fulfilled", fulfilled).put("text", shown).put("plugin", describe(plugin)))
            }
        }
    }

    /** refuses anything that isn't a plain name inside the drop dir */
    private fun resolve(context: Context, name: String?): List<File> {
        val dir = dropDir(context) ?: return emptyList()
        if (name == null) {
            return dir.listFiles { f -> f.isFile && f.name.endsWith(".js") }?.sortedBy { it.name } ?: emptyList()
        }
        if (name == "." || name == ".." || !safeName.matches(name)) return emptyList()
        return listOf(File(dir, name)).filter { it.isFile }
    }

    private fun fail(error: String): JSONObject = JSONObject().put("ok", false).put("error", error)
}
