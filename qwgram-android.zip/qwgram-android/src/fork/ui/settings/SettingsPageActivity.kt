package desu.inugram.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Paint.FontMetricsInt
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.text.Layout
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.ReplacementSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.graphics.withTranslation
import desu.inugram.SearchRegistry
import desu.inugram.helpers.InuUtils
import org.telegram.messenger.AndroidUtilities
import org.telegram.messenger.ApplicationLoader
import org.telegram.messenger.LocaleController
import org.telegram.messenger.NotificationCenter
import org.telegram.messenger.R
import org.telegram.messenger.UserConfig
import org.telegram.messenger.Utilities
import org.telegram.ui.ActionBar.ActionBar
import org.telegram.ui.ActionBar.SimpleTextView
import org.telegram.ui.ActionBar.Theme
import org.telegram.ui.Cells.NotificationsCheckCell
import org.telegram.ui.Cells.TextCell
import org.telegram.ui.Components.Bulletin
import org.telegram.ui.Components.BulletinFactory
import org.telegram.ui.Components.ItemOptions
import org.telegram.ui.Components.LayoutHelper
import org.telegram.ui.Components.RecyclerListView
import org.telegram.ui.Components.UItem
import org.telegram.ui.Components.UniversalFragment
import org.telegram.ui.Components.UniversalRecyclerView
import org.telegram.ui.LaunchActivity
import org.telegram.utils.glass.BaseFragmentSimpleGlass

abstract class SettingsPageActivity : UniversalFragment() {
    override fun isSupportEdgeToEdge(): Boolean = true

    private var highlightItemId: Int = -1

    protected open val expandableGroups: List<ExpandableBoolGroup> get() = emptyList()

    fun withHighlight(itemId: Int) = apply {
        highlightItemId = itemId
        for (group in expandableGroups) group.expandIfContains(itemId)
    }

    override fun useSimpleActionBar(): Boolean = true

    override fun getListViewForSimpleGlass(): RecyclerListView? = listView

    override fun createView(context: Context): View {
        setHasOwnBackground(true)
        return super.createView(context).also {
            listView.setSections()
            listView.setSectionsDrawBackground(true)
            listView.clipToPadding = false
            listView.setOnItemClickListener { view, position, x, y ->
                val item = listView.adapter.getItem(position) ?: return@setOnItemClickListener
                onClick(item, view, position, x, y)
                listView.adapter.update(true)
            }
            // pre-scroll before first layout so the row is on-screen at open, no jump after transition.
            if (highlightItemId != -1) {
                val index = findItemPosition(listView, highlightItemId)
                if (index >= 0) {
                    listView.layoutManager.scrollToPositionWithOffset(index, AndroidUtilities.dp(60f))
                }
            }
        }
    }

    override fun onTransitionAnimationEnd(isOpen: Boolean, backward: Boolean) {
        super.onTransitionAnimationEnd(isOpen, backward)
        if (!isOpen || backward || highlightItemId == -1) return
        val index = findItemPosition(listView, highlightItemId)
        highlightItemId = -1
        if (index >= 0) listView.highlightRow { index }
    }

    private fun findItemPosition(lv: UniversalRecyclerView, target: Int): Int {
        var i = 0
        while (true) {
            val item = lv.adapter.getItem(i) ?: return -1
            if (item.id == target) return i
            i++
        }
    }

    override fun onInsets(left: Int, top: Int, right: Int, bottom: Int) {
        stickyButtonContainer?.setPadding(dp(16), dp(8), dp(16), dp(8) + bottom)
        updateListPadding()
    }

    protected open fun getListExtraBottomPadding(): Int =
        if (stickyButtonContainer != null) dp(STICKY_BUTTON_HEIGHT) else 0

    protected fun updateListPadding() {
        BaseFragmentSimpleGlass.setListViewParams(
            listView ?: return,
            mSystemInsets.top,
            mSystemInsets.bottom,
            ActionBar.getCurrentActionBarHeight(),
            getListExtraBottomPadding(),
        )
    }

    override fun onFragmentDestroy() {
        if (stickyButtonContainer != null) Bulletin.removeDelegate(this)
        super.onFragmentDestroy()
    }

    private var stickyButtonContainer: FrameLayout? = null

    // Sticky bottom button bar (à la CloudSyncActivity): wraps `button` in a windowBackgroundWhite
    // bar, reserves matching list padding, and offsets bulletins above it. Callable both from
    // createView and later (insets seen so far are applied; onInsets keeps them in sync after).
    // Cleanup is handled in onFragmentDestroy.
    protected fun attachStickyButton(rootView: View, button: View) {
        val container = FrameLayout(rootView.context).apply {
            setBackgroundColor(Theme.getColor(Theme.key_windowBackgroundWhite))
            setPadding(dp(16), dp(8), dp(16), dp(8) + mSystemInsets.bottom)
            addView(button, LayoutHelper.createFrame(LayoutHelper.MATCH_PARENT, 48f))
        }
        stickyButtonContainer = container
        (rootView as FrameLayout).addView(
            container,
            LayoutHelper.createFrame(LayoutHelper.MATCH_PARENT, LayoutHelper.WRAP_CONTENT, Gravity.BOTTOM)
        )
        updateListPadding()
        Bulletin.addDelegate(this, object : Bulletin.Delegate {
            override fun getBottomOffset(tag: Int): Int = stickyButtonContainer?.height ?: 0
        })
    }

    private fun dp(v: Int) = AndroidUtilities.dp(v.toFloat())

    protected fun postNotificationForAllAccounts(id: Int, vararg args: Any?) {
        for (i in 0 until UserConfig.MAX_ACCOUNT_COUNT) {
            if (UserConfig.getInstance(i).isClientActivated) {
                NotificationCenter.getInstance(i).postNotificationName(id, *args)
            }
        }
    }

    // rebuilds views of all fragments below this one — settings page itself stays.
    protected fun softRebuild() {
        LaunchActivity.instance?.rebuildAllFragments(false)
    }

    // rebuilds this page too, keeping its scroll position
    protected fun rebuildAll() {
        val lm = listView.layoutManager
        val position = lm.findFirstVisibleItemPosition()
        val offset = lm.findViewByPosition(position)?.let { it.top - listView.paddingTop } ?: 0
        LaunchActivity.instance?.rebuildAllFragments(true)
        if (position >= 0) listView?.layoutManager?.scrollToPositionWithOffset(position, offset)
    }

    // redraws all visible rows; softRebuild skips the current page, so toggles that change how
    // cells draw (e.g. material 3 switches) need this to take effect live.
    protected fun invalidateVisibleRows() {
        fun walk(view: View) {
            view.invalidate()
            if (view is ViewGroup) for (i in 0 until view.childCount) walk(view.getChildAt(i))
        }
        walk(listView ?: return)
    }

    protected fun showRestartBulletin() {
        BulletinFactory.of(this)
            .createSimpleBulletin(
                R.raw.chats_infotip,
                LocaleController.getString(R.string.InuRestartRequired),
                LocaleController.getString(R.string.InuRestartNow)
            ) {
                val activity = parentActivity ?: return@createSimpleBulletin
                InuUtils.restartApp(activity)
            }
            .show()
    }

    protected fun mkTwoLineCheckItem(
        id: Int,
        textRes: Int,
        infoRes: Int,
        checked: Boolean,
        experimental: Boolean = false,
        split: Boolean = false,
    ): UItem {
        val rawText = LocaleController.getString(textRes)
        val text = if (experimental) addExperimentalSpan(rawText) else rawText
        val subtext = if (infoRes == 0) null else LocaleController.getString(infoRes)
        return UItem.asButtonCheck(id, text, subtext).also {
            it.checked = checked
            it.bind = Utilities.Callback { view ->
                if (view !is NotificationsCheckCell) return@Callback
                view.setTextAndValueAndCheck(text, subtext, checked, 0, subtext != null, view.needDivider)
                view.setDrawLine(split)
            }
        }
    }

    protected fun mkSubPageButton(id: Int, text: CharSequence): UItem {
        return UItem.asButton(id, text).also {
            it.bind = Utilities.Callback { view ->
                val cell = view as? TextCell ?: return@Callback
                val iv = cell.valueImageView
                iv.setImageResource(R.drawable.msg_arrowright)
                iv.colorFilter = PorterDuffColorFilter(
                    Theme.getColor(Theme.key_windowBackgroundWhiteGrayIcon),
                    PorterDuff.Mode.MULTIPLY,
                )
                iv.visibility = View.VISIBLE
            }
        }
    }

    protected fun mkSplitCheckItem(
        id: Int,
        textRes: Int,
        infoRes: Int,
        checked: Boolean,
    ): UItem = mkTwoLineCheckItem(id, textRes, infoRes, checked, split = true)

    class ExperimentalSpan : ReplacementSpan {
        var textPaint: TextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        var bgPaint: Paint = Paint(Paint.ANTI_ALIAS_FLAG)
        var layout: StaticLayout? = null
        var width: Float = 0f
        var height: Float = 0f

        var color = 0

        constructor() {
            textPaint.setTypeface(AndroidUtilities.bold())
            bgPaint.style = Paint.Style.FILL
            textPaint.textSize = AndroidUtilities.dp(12f).toFloat()
        }

        private var text: CharSequence? = "NEW"
        fun setText(text: CharSequence?) {
            this.text = text
            if (layout != null) {
                layout = null
                makeLayout()
            }
        }

        fun makeLayout(): StaticLayout? {
            if (layout == null) {
                layout = StaticLayout(
                    text,
                    textPaint,
                    AndroidUtilities.displaySize.x,
                    Layout.Alignment.ALIGN_NORMAL,
                    1f,
                    0f,
                    false
                )
                width = layout!!.getLineWidth(0)
                height = layout!!.height.toFloat()
            }
            return layout
        }

        override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: FontMetricsInt?): Int {
            makeLayout()
            return (AndroidUtilities.dp(10f) + width).toInt()
        }

        override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, _x: Float, top: Int, _y: Int, bottom: Int, paint: Paint) {
            makeLayout()

            bgPaint.setColor(color)
            textPaint.setColor(color)
            bgPaint.setAlpha(16)
            textPaint.setAlpha(255)

            val x = _x + AndroidUtilities.dp(2f)
            val y = (_y - layout!!.getLineBaseline(0)).toFloat()
            AndroidUtilities.rectTmp.set(x, y, x + width, y + height)
            val r = AndroidUtilities.dp(4.4f).toFloat()
            AndroidUtilities.rectTmp.inset(
                AndroidUtilities.dp(-4f).toFloat(),
                AndroidUtilities.dp(-2.33f).toFloat()
            )

            canvas.drawRoundRect(AndroidUtilities.rectTmp, r, r, bgPaint)
            canvas.withTranslation(x, y) {
                layout!!.draw(this)
            }
        }
    }

    protected fun addExperimentalSpan(string: CharSequence): CharSequence = appendTag(
        string,
        LocaleController.getString(R.string.InuExperimental),
        Theme.getColor(Theme.key_windowBackgroundWhiteBlueHeader),
    )

    override fun onLongClick(item: UItem, view: View, position: Int, x: Float, y: Float): Boolean {
        val opts = ItemOptions.makeOptions(this, view).setLongPressSelectionEnabled(false)
        val hasText = hasTruncatedText(view) && addFullTextOption(opts, item)
        opts.addGapIf(hasText && SearchRegistry.deepLinkForItemId(item.id) != null)
        val hasLink = addCopyLinkOption(opts, item)
        if (!hasText && !hasLink) return false
        opts.show()
        return true
    }

    protected fun hasTruncatedText(view: View): Boolean {
        when (view) {
            is TextView -> {
                val layout = view.layout ?: return false
                val text = view.text ?: return false
                for (i in 0 until layout.lineCount) {
                    if (layout.getEllipsisCount(i) > 0) return true
                }
                return layout.lineCount == 1 &&
                    Layout.getDesiredWidth(text, view.paint) > layout.width + 1
            }
            is SimpleTextView -> {
                val text = view.text ?: return false
                val shownWidth = view.textWidth
                if (shownWidth > view.width - view.paddingLeft - view.paddingRight) return true
                return Layout.getDesiredWidth(text, view.textPaint) > shownWidth + AndroidUtilities.dp(1f)
            }
            is ViewGroup -> {
                for (i in 0 until view.childCount) {
                    if (hasTruncatedText(view.getChildAt(i))) return true
                }
            }
        }
        return false
    }

    protected fun addFullTextOption(opts: ItemOptions, item: UItem): Boolean {
        val maxWidth = AndroidUtilities.dp(280f)
        var added = false
        if (!item.text.isNullOrEmpty()) {
            opts.addText(item.text, 14, maxWidth)
            added = true
        }
        if (!item.subtext.isNullOrEmpty()) {
            opts.addText(item.subtext, 13, maxWidth)
            added = true
        }
        return added
    }

    protected fun addCopyLinkOption(opts: ItemOptions, item: UItem): Boolean {
        val link = SearchRegistry.deepLinkForItemId(item.id) ?: return false
        opts.add(R.drawable.msg_link, LocaleController.getString(R.string.CopyLink)) {
            val cm = ApplicationLoader.applicationContext
                .getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("label", link))
            BulletinFactory.of(this).createCopyLinkBulletin().show()
        }
        return true
    }

    companion object {
        private const val STICKY_BUTTON_HEIGHT = 64

        /** [string] with a small pill of [tag] after it, the way settings badge an experiment */
        fun appendTag(string: CharSequence, tag: CharSequence, color: Int): CharSequence {
            val tagSpan = ExperimentalSpan()
            tagSpan.color = color
            tagSpan.setText(tag)

            val tagText = SpannableString(tag)
            tagText.setSpan(tagSpan, 0, tagText.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)

            val text = SpannableStringBuilder(string)
            text.append("  ")
            text.append(tagText)
            return text
        }
    }
}
