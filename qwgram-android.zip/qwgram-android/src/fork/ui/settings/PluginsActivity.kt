package desu.inugram.ui.settings

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.style.ClickableSpan
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import desu.inugram.InuConfig
import desu.inugram.helpers.plugins.BootGuard
import desu.inugram.helpers.InuUtils
import desu.inugram.helpers.plugins.Plugin
import desu.inugram.helpers.plugins.PluginDevServer
import desu.inugram.helpers.plugins.PluginImportHelper
import desu.inugram.helpers.plugins.PluginManager
import desu.inugram.helpers.plugins.ui.PluginManifestIcons
import desu.inugram.helpers.plugins.ui.PluginUi
import desu.inugram.helpers.theme.M3SectionsHelper
import org.telegram.messenger.AndroidUtilities
import org.telegram.messenger.LocaleController
import org.telegram.messenger.R
import org.telegram.messenger.Utilities
import org.telegram.ui.ActionBar.ActionBar
import org.telegram.ui.ActionBar.ActionBarMenuSubItem
import org.telegram.ui.ActionBar.AlertDialog
import org.telegram.ui.ActionBar.BaseFragment
import org.telegram.ui.ActionBar.Theme
import org.telegram.ui.Cells.NotificationsCheckCell
import org.telegram.ui.Components.BackupImageView
import org.telegram.ui.Components.BulletinFactory
import org.telegram.ui.Components.ItemOptions
import org.telegram.ui.Components.LinkSpanDrawable
import org.telegram.ui.Components.LayoutHelper
import org.telegram.ui.Components.Switch
import org.telegram.ui.Components.UItem
import org.telegram.ui.Components.UniversalAdapter

class PluginsActivity : SettingsPageActivity() {
    private val rows = HashMap<String, PluginRow>()
    private var safeModeBanner: WarningBanner? = null
    private var devBanner: WarningBanner? = null
    private var reorderSectionId = -1
    private var compactItem: ActionBarMenuSubItem? = null
    private var removeAllItem: ActionBarMenuSubItem? = null

    override fun getTitle(): CharSequence = LocaleController.getString(R.string.InuPlugins)

    private val onPluginsChanged: () -> Unit = { listView?.adapter?.update(true) }

    override fun onResume() {
        super.onResume()
        PluginManager.addOnChangedListener(onPluginsChanged)
        onPluginsChanged()
    }

    override fun onPause() {
        super.onPause()
        PluginManager.removeOnChangedListener(onPluginsChanged)
    }

    override fun createView(context: Context): View {
        // the page lists what is installed whether or not the engine is on, and with it off nothing
        // has read the store yet
        PluginManager.ensureLoaded()
        safeModeBanner = null
        devBanner = null
        val view = super.createView(context)
        listView.allowReorder(true)
        listView.setReorderLongPressEnabled(false)
        listView.listenReorder { id, items -> if (id == reorderSectionId) applyReorder(items) }

        val otherItem = simpleActionBar.createMenu().addItem(0, R.drawable.ic_ab_other)
        otherItem.contentDescription = LocaleController.getString(R.string.AccDescrMoreOptions)
        compactItem = otherItem.addSubItem(MENU_COMPACT, 0, null)
        updateCompactItem()
        removeAllItem = otherItem.addSubItem(
            MENU_REMOVE_ALL,
            R.drawable.msg_delete,
            LocaleController.getString(R.string.InuPluginsRemoveAll),
        ).apply {
            val red = getThemedColor(Theme.key_text_RedBold)
            setColors(red, red)
            visibility = if (PluginManager.plugins().isEmpty()) View.GONE else View.VISIBLE
        }
        simpleActionBar.setActionBarMenuOnItemClick(object : ActionBar.ActionBarMenuOnItemClick() {
            override fun onItemClick(id: Int) {
                when (id) {
                    -1 -> finishFragment()
                    MENU_COMPACT -> toggleCompactList()
                    MENU_REMOVE_ALL -> confirmRemoveAll()
                }
            }
        })
        return view
    }

    private fun toggleCompactList() {
        InuConfig.PLUGINS_COMPACT_LIST.toggle()
        updateCompactItem()
        rows.clear()
        listView.adapter.update(true)
    }

    /** the item is the mode it switches to, so both its label and its icon flip with the state */
    private fun updateCompactItem() {
        val compact = InuConfig.PLUGINS_COMPACT_LIST.value
        compactItem?.setTextAndIcon(
            LocaleController.getString(if (compact) R.string.InuPluginsNormalView else R.string.InuPluginsCompactView),
            if (compact) R.drawable.msg_media else R.drawable.msg_list,
        )
    }

    override fun fillItems(items: ArrayList<UItem>, adapter: UniversalAdapter) {
        // the rows below still read as enabled, because they are: safe mode is about this session
        // and nothing else, and a session that ran nothing has to say so somewhere
        safeModeNotice()?.let { notice ->
            val banner = safeModeBanner ?: WarningBanner(context, LocaleController.getString(R.string.InuRestartNow), {
                parentActivity?.let { InuUtils.restartApp(it) }
            }).also {
                it.setTitle(LocaleController.getString(R.string.InuPluginsSafeMode))
                safeModeBanner = it
            }
            banner.setText(notice)
            items.add(UItem.asCustomShadow(SAFE_MODE_BANNER, banner))
        }
        if (InuConfig.PLUGINS_DEV_MODE.value) {
            val banner = devBanner ?: WarningBanner(context, LocaleController.getString(R.string.InuPluginsDevModeTurnOff), {
                setDevMode(false)
            }).also {
                it.setTitle(LocaleController.getString(R.string.InuPluginsDevMode))
                it.setText(LocaleController.getString(R.string.InuPluginsDevModeBanner))
                devBanner = it
            }
            items.add(UItem.asCustomShadow(DEV_BANNER, banner))
        }
        items.add(UItem.asShadow(LocaleController.getString(R.string.InuPluginsInfo)))
        items.add(
            mkTwoLineCheckItem(
                ENGINE_TOGGLE,
                R.string.InuPluginsEnableEngine,
                R.string.InuPluginsEnableEngineInfo,
                PluginManager.isEngineEnabled(),
            )
        )

        items.add(UItem.asShadow(null))
        items.add(UItem.asButton(BUTTON_REPOS, R.drawable.msg_channel, LocaleController.getString(R.string.InuPluginRepos)))
        items.add(
            UItem.asButton(
                BUTTON_LOAD,
                R.drawable.msg_download,
                LocaleController.getString(R.string.InuPluginsLoadFromDisk),
            )
        )

        val plugins = PluginManager.plugins()
        removeAllItem?.visibility = if (plugins.isEmpty()) View.GONE else View.VISIBLE
        // md3 draws a header as its own detached row, so the card already ends there; the classic
        // style needs the gap spelled out, or the engine toggle and the list read as one block
        val classic = !M3SectionsHelper.isEnabled()
        if (plugins.isEmpty()) {
            items.add(UItem.asShadow(LocaleController.getString(R.string.InuPluginsEmpty)))
        } else {
            if (classic) items.add(UItem.asShadow(null))
            items.add(UItem.asHeader(LocaleController.getString(R.string.InuPluginsInstalled)))
            reorderSectionId = adapter.reorderSectionStart()
            plugins.forEachIndexed { i, plugin ->
                items.add(buildRow(plugin, divider = classic && i != plugins.lastIndex))
            }
            adapter.reorderSectionEnd()
        }

        items.add(UItem.asShadow(null))
        items.add(
            mkTwoLineCheckItem(
                DEV_TOGGLE,
                R.string.InuPluginsDevMode,
                R.string.InuPluginsDevModeInfo,
                InuConfig.PLUGINS_DEV_MODE.value,
            )
        )
        items.add(UItem.asShadow(null))
    }

    private fun safeModeNotice(): CharSequence? = when (PluginManager.safeModeReason) {
        BootGuard.Reason.FORCED -> LocaleController.getString(R.string.InuPluginsSafeModeForced)
        BootGuard.Reason.CRASHED -> LocaleController.getString(R.string.InuPluginsSafeModeCrashed)
        BootGuard.Reason.CRASH_LOOP -> LocaleController.getString(R.string.InuPluginsSafeModeCrashLoop)
        BootGuard.Reason.HOST_ERROR -> LocaleController.getString(R.string.InuPluginsSafeModeHostError)
        null -> null
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildRow(plugin: Plugin, divider: Boolean): UItem {
        val compact = InuConfig.PLUGINS_COMPACT_LIST.value
        var row = rows[plugin.id]
        if (row == null || row.compact != compact) {
            row = PluginRow(context, compact).also { newRow ->
                newRow.setOnReorderTouchListener { _, event ->
                    if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                        val holder = listView.findContainingViewHolder(newRow) ?: return@setOnReorderTouchListener false
                        listView.itemTouchHelper.startDrag(holder)
                    }
                    false
                }
            }
            rows[plugin.id] = row
        }
        row.bind(
            plugin,
            onOpen = { presentFragment(PluginInfoActivity(plugin)) },
            onUsernameClick = { username -> messagesController.openByUserName(username, this, 0) },
            onMenu = { anchor -> showPluginOptions(plugin, anchor) },
        ) { enabled ->
            PluginManager.setEnabled(plugin, enabled)
        }
        row.bindSettings(if (plugin.settingsPageId != null) ({ PluginUi.openRegisteredSettings(plugin) }) else null)
        row.bindActions(
            onReload = { PluginManager.reload(plugin) },
            onRemove = { removePlugin(plugin) },
        )
        row.setDivider(divider)
        val uitem = if (compact) UItem.asCustom(row, PluginRow.HEIGHT_DP) else UItem.asCustom(row)
        uitem.id = ITEM_BASE + (plugin.id.hashCode() and 0xffff)
        uitem.`object` = plugin
        return uitem
    }

    private fun applyReorder(items: List<UItem>) {
        val ordered = items.mapNotNull { it.`object` as? Plugin }
        if (ordered.size != PluginManager.plugins().size) return
        PluginManager.setOrder(ordered)
    }

    override fun onClick(item: UItem, view: View, position: Int, x: Float, y: Float) {
        when (item.id) {
            ENGINE_TOGGLE -> {
                // the switch has to animate before the rebind below sets it non-animated: an
                // already-checked Switch ignores the second setChecked, so the animation survives
                (view as? NotificationsCheckCell)?.isChecked = PluginManager.toggleEngine()
                listView.adapter.update(true)
            }
            DEV_TOGGLE -> {
                if (InuConfig.PLUGINS_DEV_MODE.value) {
                    (view as? NotificationsCheckCell)?.isChecked = false
                    setDevMode(false)
                } else {
                    val ctx = context ?: parentActivity ?: return
                    PluginConsentSheet.show(
                        ctx,
                        resourceProvider,
                        titleRes = R.string.InuPluginsDevModeSheetTitle,
                        infoRes = R.string.InuPluginsDevModeSheetInfo,
                        features = listOf(
                            PluginConsentSheet.Feature(R.drawable.msg2_devices, R.string.InuPluginsDevMode1Title, R.string.InuPluginsDevMode1Text),
                            PluginConsentSheet.Feature(R.drawable.msg_permissions, R.string.InuPluginsDevMode2Title, R.string.InuPluginsDevMode2Text),
                            PluginConsentSheet.Feature(R.drawable.inu_tabler_code, R.string.InuPluginsDevMode3Title, R.string.InuPluginsDevMode3Text),
                        ),
                        warningRes = R.string.InuPluginsDevModeSheetWarning,
                        acceptRes = R.string.InuPluginsDevModeSheetAccept,
                    ) { setDevMode(true) }
                }
            }
            BUTTON_LOAD -> launchLoad()
            BUTTON_REPOS -> presentFragment(PluginReposActivity())
            // plugin rows handle their own clicks (see PluginRow's background comment)
        }
    }

    private fun showPluginOptions(plugin: Plugin, anchor: View) {
        ItemOptions.makeOptions(this, anchor)
            .addIf(plugin.enabled, R.drawable.msg_reset, LocaleController.getString(R.string.InuPluginsReload)) {
                PluginManager.reload(plugin)
            }
            .add(R.drawable.msg_share, LocaleController.getString(R.string.ShareFile)) {
                sharePlugin(this, plugin)
            }
            .add(R.drawable.msg_delete, LocaleController.getString(R.string.InuPluginsRemove), true) {
                removePlugin(plugin)
            }
            .show()
    }

    private fun removePlugin(plugin: Plugin) {
        confirmRemovePlugins(
            this,
            listOf(plugin),
            LocaleController.formatString(R.string.InuPluginsRemoveTitle, plugin.manifest.name),
            LocaleController.getString(R.string.InuPluginsRemoveConfirm),
        ) {
            rows.remove(plugin.id)
            listView.adapter.update(true)
        }
    }

    private fun setDevMode(enabled: Boolean) {
        InuConfig.PLUGINS_DEV_MODE.value = enabled
        val ctx = context ?: parentActivity
        if (ctx != null) PluginDevServer.sync(ctx)
        listView.adapter.update(true)
    }

    private fun confirmRemoveAll() {
        val plugins = PluginManager.plugins()
        if (plugins.isEmpty()) return
        confirmRemovePlugins(
            this,
            plugins,
            LocaleController.getString(R.string.InuPluginsRemoveAll),
            LocaleController.formatPluralString("InuPluginsRemoveAllConfirm", plugins.size),
        ) {
            rows.clear()
            listView.adapter.update(true)
        }
    }

    private fun launchLoad() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/javascript", "text/javascript", "text/plain", "*/*"))
        }
        try {
            startActivityForResult(intent, REQ_LOAD)
        } catch (e: Exception) {
            BulletinFactory.of(this).createErrorBulletin(e.message ?: "").show()
        }
    }

    override fun onActivityResultFragment(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != REQ_LOAD || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        val ctx = context ?: parentActivity ?: return
        Utilities.globalQueue.postRunnable {
            val source = try {
                ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            } catch (_: Exception) {
                null
            }
            AndroidUtilities.runOnUIThread {
                if (source == null) {
                    BulletinFactory.of(this).createErrorBulletin(
                        LocaleController.getString(R.string.InuPluginsErrorRead)
                    ).show()
                    return@runOnUIThread
                }
                PluginImportHelper.startImport(this, source)
            }
        }
    }

    companion object {
        val ENGINE_TOGGLE = InuUtils.generateId()
        private val BUTTON_LOAD = InuUtils.generateId()
        private val BUTTON_REPOS = InuUtils.generateId()
        private val SAFE_MODE_BANNER = InuUtils.generateId()
        private val DEV_BANNER = InuUtils.generateId()
        private val DEV_TOGGLE = InuUtils.generateId()
        private const val MENU_COMPACT = 1
        private const val MENU_REMOVE_ALL = 2
        private const val ITEM_BASE = 20000
        private const val REQ_LOAD = 31010
    }
}

@SuppressLint("ViewConstructor")
class PluginRow(context: Context, val compact: Boolean) : LinearLayout(context) {
    private val handle: ImageView
    private val icon: BackupImageView
    private val placeholder = PluginManifestIcons.createPlaceholder(context)
    private val title = RowTitle(context)
    private val subtitle: TextView
    private val switch: Switch
    private val settingsButton: ImageView
    private var description: TextView? = null
    private var settingsAction: TextView? = null
    private var reloadAction: TextView? = null
    private var removeAction: TextView? = null
    private var onToggle: ((Boolean) -> Unit)? = null
    private var onOpen: (() -> Unit)? = null
    private var onUsernameClick: ((String) -> Unit)? = null
    private var onMenu: ((View) -> Unit)? = null
    private var needDivider = false

    init {
        orientation = VERTICAL
        // the row consumes its own touches (making RecyclerListView's item-click skip it via
        // interceptedByChild) so taps on the switch/settings/handle children don't also open
        // the info page
        background = Theme.createSelectorWithBackgroundDrawable(
            Theme.getColor(Theme.key_windowBackgroundWhite),
            Theme.getColor(Theme.key_listSelector),
        )
        setOnClickListener { onOpen?.invoke() }
        setOnLongClickListener { onMenu?.invoke(this); true }
        val rtl = LocaleController.isRTL

        handle = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            setImageResource(R.drawable.list_reorder)
            colorFilter = PorterDuffColorFilter(Theme.getColor(Theme.key_stickers_menu), PorterDuff.Mode.MULTIPLY)
            contentDescription = LocaleController.getString(R.string.FilterReorder)
            isClickable = true
        }
        icon = BackupImageView(context).apply {
            setRoundRadius(AndroidUtilities.dp(if (compact) 6f else 8f))
        }
        subtitle = LinkSpanDrawable.LinksTextView(context).apply {
            setLinkTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteLinkText))
            setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteGrayText))
            textSize = 13f
            maxLines = if (compact) 2 else 1
            ellipsize = TextUtils.TruncateAt.END
        }
        settingsButton = ImageView(context).apply {
            setImageResource(R.drawable.msg_settings)
            setColorFilter(Theme.getColor(Theme.key_windowBackgroundWhiteGrayIcon))
            background = Theme.createSelectorDrawable(
                Theme.getColor(Theme.key_listSelector),
                Theme.RIPPLE_MASK_CIRCLE_20DP,
            )
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            contentDescription = LocaleController.getString(R.string.Settings)
            visibility = GONE
        }
        switch = Switch(context).apply {
            setColors(Theme.key_switchTrack, Theme.key_switchTrackChecked, Theme.key_windowBackgroundWhite, Theme.key_windowBackgroundWhite)
            setOnClickListener {
                val next = !isChecked
                setChecked(next, true)
                onToggle?.invoke(next)
            }
        }

        val textBlock = LinearLayout(context).apply { orientation = VERTICAL }
        // wrap_content, so the warning drawable hugs the name instead of the row's right edge
        textBlock.addView(title, LayoutHelper.createLinear(LayoutHelper.WRAP_CONTENT, LayoutHelper.WRAP_CONTENT))
        textBlock.addView(subtitle, LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, LayoutHelper.WRAP_CONTENT, 0f, 2f, 0f, 0f))

        if (compact) {
            minimumHeight = AndroidUtilities.dp(HEIGHT_DP.toFloat())
            val header = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            header.addView(handle, LayoutHelper.createLinear(40, 48, Gravity.CENTER_VERTICAL, if (rtl) 0 else 8, 0, if (rtl) 8 else 0, 0))
            header.addView(icon, LayoutHelper.createLinear(28, 28, Gravity.CENTER_VERTICAL, if (rtl) 0 else 8, 0, if (rtl) 8 else 14, 0))
            header.addView(textBlock, LayoutHelper.createLinear(0, LayoutHelper.WRAP_CONTENT, 1f, Gravity.CENTER_VERTICAL))
            header.addView(settingsButton, LayoutHelper.createLinear(40, 40, Gravity.CENTER_VERTICAL, 0, 0, if (rtl) 0 else 4, 0))
            header.addView(switch, LayoutHelper.createLinear(37, 24, Gravity.CENTER_VERTICAL, if (rtl) 22 else 0, 0, if (rtl) 0 else 22, 0))
            addView(header, LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, HEIGHT_DP))
        } else {
            // icon above the handle in one narrow gutter, so title and description share a single
            // text column instead of clearing both of them; actions reclaim the gutter's width below it
            val gutter = LinearLayout(context).apply {
                orientation = VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            gutter.addView(icon, LayoutHelper.createLinear(32, 32, Gravity.CENTER_HORIZONTAL, 0f, 4f, 0f, 0f))
            gutter.addView(handle, LayoutHelper.createLinear(40, 40, Gravity.CENTER_HORIZONTAL, 0f, 4f, 0f, 0f))

            val titleRow = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            titleRow.addView(textBlock, LayoutHelper.createLinear(0, LayoutHelper.WRAP_CONTENT, 1f, Gravity.CENTER_VERTICAL))
            titleRow.addView(switch, LayoutHelper.createLinear(37, 24, Gravity.CENTER_VERTICAL, if (rtl) 22 else 0, 0, if (rtl) 0 else 22, 0))

            description = LinkSpanDrawable.LinksTextView(context).apply {
                setLinkTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteLinkText))
                setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteGrayText))
                textSize = 14f
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
            }

            val actions = RowActions(context)
            settingsAction = actions.addAction(R.string.Settings, red = false).also { it.visibility = GONE }
            reloadAction = actions.addAction(R.string.InuPluginsReload, red = false)
            removeAction = actions.addAction(R.string.InuPluginsRemove, red = true)

            val content = LinearLayout(context).apply { orientation = VERTICAL }
            content.addView(titleRow, LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, LayoutHelper.WRAP_CONTENT))
            content.addView(
                description,
                LayoutHelper.createLinear(
                    LayoutHelper.MATCH_PARENT, LayoutHelper.WRAP_CONTENT, Gravity.NO_GRAVITY,
                    if (rtl) 22 else 0, 4, if (rtl) 0 else 22, 0,
                ),
            )

            val body = RowBody(context, gutter, content, actions)
            addView(
                body,
                LayoutHelper.createLinear(LayoutHelper.MATCH_PARENT, LayoutHelper.WRAP_CONTENT, 0f, 10f, 0f, 10f),
            )
        }
    }

    fun bind(plugin: Plugin, onOpen: () -> Unit, onUsernameClick: (String) -> Unit, onMenu: (View) -> Unit, onToggle: (Boolean) -> Unit) {
        this.onToggle = onToggle
        this.onOpen = onOpen
        this.onUsernameClick = onUsernameClick
        this.onMenu = onMenu
        PluginManifestIcons.bindIcon(icon, plugin.manifest.icon, placeholder)
        title.text = if (plugin.dev) {
            SettingsPageActivity.appendTag(
                plugin.manifest.name,
                LocaleController.getString(R.string.InuPluginsDevChip),
                Theme.getColor(Theme.key_windowBackgroundWhiteBlueHeader),
            )
        } else {
            plugin.manifest.name
        }
        val tier = highestGrantTier(plugin.manifest)
        title.setWarning(tier?.let { tierColors(it).first })
        val failure = plugin.failure
        if (compact) {
            if (failure != null) {
                subtitle.setTextColor(Theme.getColor(Theme.key_text_RedRegular))
                subtitle.text = failure.describe()
            } else {
                subtitle.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteGrayText))
                subtitle.text = plugin.manifest.description(LocaleController.getInstance().currentLocaleInfo?.langCode)?.let(::formatDescription)
                    ?: plugin.manifest.author?.let { linkUsernames(LocaleController.formatString(R.string.InuPluginsByAuthor, it)) }
                    ?: ""
            }
        } else {
            val meta = buildMetaLine(plugin)
            subtitle.text = linkUsernames(meta)
            subtitle.visibility = if (meta.isEmpty()) GONE else VISIBLE
            val text = failure?.describe()
                ?: plugin.manifest.description(LocaleController.getInstance().currentLocaleInfo?.langCode)
            description?.let {
                it.setTextColor(Theme.getColor(if (failure != null) Theme.key_text_RedRegular else Theme.key_windowBackgroundWhiteGrayText))
                it.text = if (failure == null) formatDescription(text ?: "") else text ?: ""
                it.visibility = if (text.isNullOrEmpty()) GONE else VISIBLE
            }
        }
        reloadAction?.visibility = if (plugin.enabled) VISIBLE else GONE
        switch.setChecked(plugin.enabled, false)
    }

    private fun linkUsernames(text: String): CharSequence =
        InuUtils.linkUsernames(text) { username -> onUsernameClick?.invoke(username) }

    private fun formatDescription(text: String): CharSequence =
        formatPluginDescription(text) { username -> onUsernameClick?.invoke(username) }

    private fun buildMetaLine(plugin: Plugin): String {
        val parts = ArrayList<String>()
        plugin.manifest.version?.let { parts.add("v$it") }
        plugin.manifest.author?.let { parts.add(LocaleController.formatString(R.string.InuPluginsByAuthor, it)) }
        return parts.joinToString(" · ")
    }

    /** non-null == the plugin registered a settings page; shows the gear / settings action */
    fun bindSettings(onOpen: (() -> Unit)?) {
        if (compact) {
            settingsButton.visibility = if (onOpen != null) VISIBLE else GONE
            settingsButton.setOnClickListener { onOpen?.invoke() }
        } else {
            settingsAction?.visibility = if (onOpen != null) VISIBLE else GONE
            settingsAction?.setOnClickListener { onOpen?.invoke() }
        }
    }

    fun bindActions(onReload: () -> Unit, onRemove: () -> Unit) {
        reloadAction?.setOnClickListener { onReload() }
        removeAction?.setOnClickListener { onRemove() }
    }

    /** classic-sections only: md3 cards separate rows by shape instead */
    fun setDivider(value: Boolean) {
        if (needDivider == value) return
        needDivider = value
        invalidate()
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        if (!needDivider) return
        // starts where the text column does, past the handle/icon gutter
        drawRowDivider(canvas, if (compact) COMPACT_DIVIDER_INSET_DP else ROOMY_DIVIDER_INSET_DP)
    }

    fun setOnReorderTouchListener(listener: OnTouchListener) {
        handle.setOnTouchListener(listener)
    }

    companion object {
        const val HEIGHT_DP = 64
        private const val COMPACT_DIVIDER_INSET_DP = 98f
        private const val ROOMY_DIVIDER_INSET_DP = 60f
    }
}

internal fun confirmRemovePlugins(
    fragment: BaseFragment,
    plugins: List<Plugin>,
    title: CharSequence,
    message: CharSequence,
    onRemoved: () -> Unit,
) {
    val ctx = fragment.parentActivity ?: return
    val dialog = AlertDialog.Builder(ctx, fragment.resourceProvider)
        .setTitle(title)
        .setMessage(message)
        .setNegativeButton(LocaleController.getString(R.string.Cancel), null)
        .setPositiveButton(LocaleController.getString(R.string.Remove)) { _, _ ->
            for (plugin in plugins) PluginManager.remove(plugin)
            onRemoved()
        }
        .create()
    fragment.showDialog(dialog)
    (dialog.getButton(Dialog.BUTTON_POSITIVE) as? TextView)
        ?.setTextColor(fragment.getThemedColor(Theme.key_text_RedBold))
}
