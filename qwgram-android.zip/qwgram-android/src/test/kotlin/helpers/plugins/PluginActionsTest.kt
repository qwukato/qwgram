package desu.inugram.helpers.plugins

import desu.inugram.helpers.plugins.ui.ActionKey
import desu.inugram.helpers.plugins.ui.ActionRow
import desu.inugram.helpers.plugins.ui.ActionSurface
import desu.inugram.helpers.plugins.ui.MessageActionSource
import desu.inugram.helpers.plugins.ui.PluginActions
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue
import org.json.JSONObject
import org.junit.Before
import org.junit.Test
import org.telegram.tgnet.TLRPC

class PluginActionsTest {
    @Before
    fun setUp() = resetBridge()

    private fun Plugin.answers(vararg rows: Pair<Int, String>) {
        js.onRenderActions = { _, _ ->
            rows.joinToString(",", "[", "]") { (token, text) -> """{"token":$token,"text":"$text"}""" }
        }
    }

    private fun rendered(kind: Int, surface: ActionSurface): List<String> {
        val out = ArrayList<String>()
        PluginActions.render(kind, surface) { rows -> out.addAll(rows.map { it.text }) }
        settle()
        return out
    }

    private val chat = ActionSurface.chat(0, 4242L, null)

    @Test
    fun rows_follow_the_plugin_list_rather_than_the_order_registrations_arrived() {
        val second = startPlugin("second")
        val first = startPlugin("first")
        PluginActions.register(second.session!!, PluginActions.KIND_CHAT, 1, "b")
        PluginActions.register(first.session!!, PluginActions.KIND_CHAT, 1, "a")
        second.answers(1 to "second")
        first.answers(1 to "first")

        assertEquals(listOf("second", "first"), rendered(PluginActions.KIND_CHAT, chat))

        setInstalledPlugins(listOf(first, second))
        assertEquals(listOf("first", "second"), rendered(PluginActions.KIND_CHAT, chat))
    }

    @Test
    fun a_secret_chat_is_never_rendered_and_no_engine_is_even_asked() {
        val plugin = startPlugin("p")
        PluginActions.register(plugin.session!!, PluginActions.KIND_CHAT, 1, "a")
        plugin.answers(1 to "row")

        val secret = ActionSurface.chat(0, DialogObjectIds.ENCRYPTED, null)
        assertEquals(emptyList(), rendered(PluginActions.KIND_CHAT, secret))
        assertEquals(0, plugin.js.actionRenders.size)
    }

    @Test
    fun static_rows_are_returned_without_entering_the_engine() {
        val plugin = startPlugin("p")
        PluginActions.register(
            plugin.session!!,
            PluginActions.KIND_CHAT,
            1,
            "a",
            text = "Static",
            icon = "rmsg_pin",
            dynamicFields = 0,
        )

        assertEquals(listOf("Static"), rendered(PluginActions.KIND_CHAT, chat))
        assertEquals(0, plugin.js.actionRenders.size)
    }

    @Test
    fun cached_and_dynamic_rows_are_merged_in_registration_order() {
        val plugin = startPlugin("p")
        PluginActions.register(
            plugin.session!!,
            PluginActions.KIND_CHAT,
            1,
            "static",
            text = "Static",
            dynamicFields = 0,
        )
        PluginActions.register(
            plugin.session!!,
            PluginActions.KIND_CHAT,
            2,
            "dynamic",
            icon = "rmsg_pin",
            dynamicFields = PluginActions.DYNAMIC_TEXT,
        )
        plugin.answers(2 to "Dynamic")

        assertEquals(listOf("Static", "Dynamic"), rendered(PluginActions.KIND_CHAT, chat))
        assertEquals(1, plugin.js.actionRenders.size)
    }

    @Test
    fun settings_ignore_a_dynamic_visibility_getter() {
        val plugin = startPlugin("p")
        PluginActions.register(
            plugin.session!!,
            PluginActions.KIND_CHAT,
            1,
            "a",
            text = "Static",
            dynamicFields = PluginActions.DYNAMIC_VISIBLE,
        )

        val rows = ArrayList<ActionRow>()
        PluginActions.renderSettings(PluginActions.KIND_CHAT) { rows.addAll(it) }
        settle()

        assertEquals(listOf("Static"), rows.map { it.text })
        assertEquals(0, plugin.js.actionRenders.size)
    }

    @Test
    fun main_rows_follow_the_configured_order_and_append_unknown_rows() {
        val a = ActionKey("p", PluginActions.KIND_MESSAGE, "a")
        val b = ActionKey("p", PluginActions.KIND_MESSAGE, "b")
        val c = ActionKey("p", PluginActions.KIND_MESSAGE, "c")
        PluginActions.resetSettings(PluginActions.KIND_MESSAGE)
        try {
            PluginActions.setMainOrder(
                PluginActions.KIND_MESSAGE,
                listOf(PluginActions.pluginOrderKey(c), PluginActions.pluginOrderKey(a)),
            )
            assertEquals(listOf(c, a, b), PluginActions.orderMainKeys(PluginActions.KIND_MESSAGE, listOf(a, b, c)))
        } finally {
            PluginActions.resetSettings(PluginActions.KIND_MESSAGE)
        }
    }

    @Test
    fun a_row_whose_engine_is_no_longer_listed_does_nothing_when_tapped() {
        val plugin = startPlugin("p")
        PluginActions.register(plugin.session!!, PluginActions.KIND_CHAT, 7, "a")
        plugin.answers(7 to "row")

        val rows = ArrayList<ActionRow>()
        PluginActions.render(PluginActions.KIND_CHAT, chat) { rows.addAll(it) }
        settle()
        assertEquals(1, rows.size)

        setInstalledPlugins(emptyList())
        PluginActions.dispatch(rows[0], chat)
        settle()
        assertEquals(0, plugin.js.actionDispatches.size)

        setInstalledPlugins(listOf(plugin))
        PluginActions.dispatch(rows[0], chat)
        settle()
        assertEquals(1, plugin.js.actionDispatches.size)
        assertEquals(7, plugin.js.actionDispatches[0].token)
        assertEquals(PluginActions.KIND_CHAT, plugin.js.actionDispatches[0].kind)
        assertFalse(plugin.js.actionDispatches[0].secondary)
    }

    @Test
    fun a_primary_only_row_does_not_dispatch_on_long_tap() {
        val plugin = startPlugin("p")
        PluginActions.register(
            plugin.session!!,
            PluginActions.KIND_CHAT,
            7,
            "a",
            text = "row",
            dynamicFields = 0,
        )
        val rows = ArrayList<ActionRow>()
        PluginActions.render(PluginActions.KIND_CHAT, chat) { rows.addAll(it) }
        settle()

        assertTrue(PluginActions.dispatch(rows.single(), chat))
        assertFalse(PluginActions.dispatch(rows.single(), chat, true))
        settle()
        assertEquals(1, plugin.js.actionDispatches.size)
        assertFalse(plugin.js.actionDispatches.single().secondary)
    }

    @Test
    fun message_surface_carries_filtered_raw_messages_for_native_wrapping() {
        val plugin = startPlugin("p")
        PluginActions.register(
            plugin.session!!,
            PluginActions.KIND_MESSAGE,
            1,
            "a",
            PluginActions.MESSAGE_PLACEMENT_SELECTION,
        )
        plugin.answers(1 to "row")

        val surface = ActionSurface.message(
            0,
            4242L,
            99L,
            MessageActionSource.SELECTION,
            listOf(
                TLRPC.TL_message().apply {
                    id = 11
                    date = 1
                    message = "one"
                    dialog_id = 4242L
                    grouped_id = 7L
                }.synced(),
                TLRPC.TL_message().apply {
                    id = 12
                    date = 2
                    message = "two"
                    dialog_id = 4242L
                    grouped_id = 7L
                }.synced(),
                TLRPC.TL_message().apply {
                    id = 13
                    date = 3
                    message = "three"
                    dialog_id = -99L
                }.synced(),
            ),
        )
        rendered(PluginActions.KIND_MESSAGE, surface)

        assertEquals(1, plugin.js.actionRenders.size)
        val json = JSONObject(plugin.js.actionRenders[0].surfaceJson)
        assertEquals(4242L, json.getLong("dialogId"))
        assertEquals(99L, json.getLong("topicId"))
        assertEquals("selection", json.getString("source"))
        val messages = json.getJSONArray("messages")
        assertEquals(listOf(11, 12, 13), (0 until messages.length()).map { messages.getJSONObject(it).getInt("id") })
        assertEquals("7", messages.getJSONObject(0).getString("grouped_id"))
        assertEquals("-99", messages.getJSONObject(2).getString("dialog_id"))
    }

    @Test
    fun an_engine_that_could_not_answer_contributes_nothing_and_the_rest_still_draw() {
        val broken = startPlugin("broken")
        val fine = startPlugin("fine")
        PluginActions.register(broken.session!!, PluginActions.KIND_CHAT, 1, "a")
        PluginActions.register(fine.session!!, PluginActions.KIND_CHAT, 1, "b")
        broken.js.onRenderActions = { _, _ -> null }
        fine.answers(1 to "fine")

        assertEquals(listOf("fine"), rendered(PluginActions.KIND_CHAT, chat))
    }

    @Test
    fun an_engine_still_rendering_at_the_budget_is_abandoned_with_its_settled_rows_kept() {
        val slow = startPlugin("slow")
        val fine = startPlugin("fine")
        PluginActions.register(slow.session!!, PluginActions.KIND_CHAT, 1, "a")
        PluginActions.register(slow.session!!, PluginActions.KIND_CHAT, 2, "settled")
        PluginActions.register(fine.session!!, PluginActions.KIND_CHAT, 1, "b")
        slow.js.holdsActionRenders = true
        slow.js.abandonedRows = """[{"token":2,"text":"settled"}]"""
        fine.answers(1 to "fine")

        val out = ArrayList<List<String>>()
        PluginActions.render(PluginActions.KIND_CHAT, chat) { rows -> out.add(rows.map { it.text }) }
        settle()
        assertEquals(emptyList(), out)

        advanceBy(PluginActions.RENDER_BUDGET_MS)
        settle()
        assertEquals(listOf(listOf("settled", "fine")), out)
        assertEquals(listOf(slow.js.actionRenders.single().renderId), slow.js.actionRenderAbandons)

        PluginActions.settleRender(slow.js, slow.js.actionRenders.single().renderId, """[{"token":1,"text":"late"}]""")
        settle()
        assertEquals(1, out.size)
    }

    @Test
    fun an_engine_detached_mid_render_stops_holding_the_menu() {
        val slow = startPlugin("slow")
        val fine = startPlugin("fine")
        PluginActions.register(slow.session!!, PluginActions.KIND_CHAT, 1, "a")
        PluginActions.register(fine.session!!, PluginActions.KIND_CHAT, 1, "b")
        slow.js.holdsActionRenders = true
        fine.answers(1 to "fine")

        val out = ArrayList<List<String>>()
        PluginActions.render(PluginActions.KIND_CHAT, chat) { rows -> out.add(rows.map { it.text }) }
        settle()
        PluginActions.detach(slow.session!!)
        settle()
        assertEquals(listOf(listOf("fine")), out)
    }

    private fun renderOnEngine(): ArrayList<List<String>> {
        val out = ArrayList<List<String>>()
        PluginActions.render(PluginActions.KIND_CHAT, chat) { rows -> out.add(rows.map { it.text }) }
        settle()
        return out
    }

    @Test
    fun a_real_engine_awaits_async_getters_and_drops_rows_that_reject_or_hide() {
        val plugin = startEngine("async", actions = true)
        plugin.js(
            """
            const tick = async value => { await null; await null; return value }
            inu.registerChatAction({ id: 'a', text: ctx => tick(`chat ${'$'}{ctx.dialogId}`), visible: () => tick(true), callback: () => {} })
            inu.registerChatAction({ id: 'b', text: 'hidden', visible: async () => false, callback: () => {} })
            inu.registerChatAction({ id: 'c', text: async () => { throw new Error('nope') }, callback: () => {} })
            inu.registerChatAction({ id: 'd', text: 'static', visible: () => true, callback: () => {} })
            """,
        )

        assertEquals(listOf(listOf("chat 4242", "static")), renderOnEngine())
    }

    @Test
    fun a_real_engine_answers_when_a_getter_settles_in_a_later_engine_turn() {
        val plugin = startEngine("async", actions = true)
        plugin.js(
            """
            globalThis.__resolve = []
            inu.registerChatAction({ id: 'a', text: () => new Promise(resolve => __resolve.push(resolve)), callback: () => {} })
            """,
        )

        val out = renderOnEngine()
        assertEquals(emptyList(), out)
        plugin.js("__resolve.forEach(resolve => resolve('late but in budget'))")
        settle()
        assertEquals(listOf(listOf("late but in budget")), out)
    }

    @Test
    fun a_real_engine_that_never_settles_is_cut_off_at_the_budget_with_its_settled_rows_kept() {
        val plugin = startEngine("async", actions = true)
        plugin.js(
            """
            globalThis.__resolve = []
            inu.registerChatAction({ id: 'a', text: () => new Promise(resolve => __resolve.push(resolve)), callback: () => {} })
            inu.registerChatAction({ id: 'b', text: 'static', callback: () => {} })
            inu.registerChatAction({ id: 'c', text: async () => 'settled', callback: () => {} })
            """,
        )

        val out = renderOnEngine()
        advanceBy(PluginActions.RENDER_BUDGET_MS)
        settle()
        assertEquals(listOf(listOf("static", "settled")), out)

        plugin.js("__resolve.forEach(resolve => resolve('too late'))")
        settle()
        assertEquals(1, out.size)

        val again = renderOnEngine()
        plugin.js("__resolve.at(-1)('again')")
        settle()
        assertEquals(listOf(listOf("again", "static", "settled")), again)
    }

    @Test
    fun the_row_count_is_answerable_without_entering_any_engine_and_follows_registrations() {
        val plugin = startPlugin("p")
        assertEquals(0, PluginActions.rowCount(PluginActions.KIND_CHAT))

        assertNull(PluginActions.register(plugin.session!!, PluginActions.KIND_CHAT, 1, "a"))
        assertNull(PluginActions.register(plugin.session!!, PluginActions.KIND_CHAT, 2, "b"))
        assertEquals(2, PluginActions.rowCount(PluginActions.KIND_CHAT))
        assertNull(PluginActions.register(plugin.session!!, PluginActions.KIND_MESSAGE, 3, "c", PluginActions.MESSAGE_PLACEMENT_SELECTION))
        assertEquals(0, PluginActions.rowCount(PluginActions.KIND_MESSAGE))
        assertEquals(1, PluginActions.rowCount(PluginActions.KIND_MESSAGE, PluginActions.MESSAGE_PLACEMENT_SELECTION))
        assertTrue(plugin.js.actionRenders.isEmpty())

        PluginActions.unregister(plugin.js, PluginActions.KIND_CHAT, 1)
        assertEquals(1, PluginActions.rowCount(PluginActions.KIND_CHAT))

        PluginActions.detach(plugin.session!!)
        assertEquals(0, PluginActions.rowCount(PluginActions.KIND_CHAT))
    }

    @Test
    fun message_settings_include_selection_only_rows() {
        val plugin = startPlugin("p")
        PluginActions.register(
            plugin.session!!,
            PluginActions.KIND_MESSAGE,
            1,
            "selection",
            PluginActions.MESSAGE_PLACEMENT_SELECTION,
        )
        plugin.answers(1 to "selection")

        val rows = ArrayList<ActionRow>()
        PluginActions.renderSettings(PluginActions.KIND_MESSAGE) { rows.addAll(it) }
        settle()

        assertEquals(listOf("selection"), rows.map { it.text })
    }

    @Test
    fun the_ninth_row_is_refused_but_updating_one_of_the_eight_is_not() {
        val plugin = startPlugin("p")
        for (token in 1..8) {
            assertNull(PluginActions.register(plugin.session!!, PluginActions.KIND_CHAT, token, "row$token"))
        }
        assertNotNull(PluginActions.register(plugin.session!!, PluginActions.KIND_CHAT, 9, "row9"))
        assertEquals(8, PluginActions.rowCount(PluginActions.KIND_CHAT))

        // the engine mints the replacement's token before retiring the old one
        assertNull(PluginActions.register(plugin.session!!, PluginActions.KIND_CHAT, 10, "row1"))
        PluginActions.unregister(plugin.js, PluginActions.KIND_CHAT, 1)
        assertEquals(8, PluginActions.rowCount(PluginActions.KIND_CHAT))
    }

    @Test
    fun a_detached_engine_is_neither_counted_nor_asked_nor_dispatched_to() {
        val plugin = startPlugin("p")
        PluginActions.register(plugin.session!!, PluginActions.KIND_CHAT, 1, "a")
        plugin.answers(1 to "row")

        PluginActions.detach(plugin.session!!)
        assertEquals(emptyList(), rendered(PluginActions.KIND_CHAT, chat))
        assertEquals(0, plugin.js.actionRenders.size)
    }
}

private object DialogObjectIds {
    const val ENCRYPTED = 0x4000000000000000L or 7L
}
